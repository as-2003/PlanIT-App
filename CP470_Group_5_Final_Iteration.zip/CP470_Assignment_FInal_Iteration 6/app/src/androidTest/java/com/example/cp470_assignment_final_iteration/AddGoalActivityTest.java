package com.example.cp470_assignment_final_iteration;

import android.content.Intent;

import androidx.test.espresso.ViewAssertion;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.cp470_assignment_final_iteration.Goals.AddGoalActivity;
import com.example.cp470_assignment_final_iteration.R;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.*;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.*;

@RunWith(AndroidJUnit4.class)
public class AddGoalActivityTest {

    @Rule
    public ActivityScenarioRule<AddGoalActivity> activityRule =
            new ActivityScenarioRule<>(AddGoalActivity.class);

    @Test
    public void testSpinnerHasCategories() {
        // Verify Spinner has default categories
        onView(withId(R.id.categorySpinner))
                .check(matches(isDisplayed()))
                .perform(click());

        onView(withText("Personal")).check(matches(isDisplayed()));
        onView(withText("Work")).check(matches(isDisplayed()));
        onView(withText("Academic")).check(matches(isDisplayed()));
        onView(withText("Other")).check(matches(isDisplayed()));
    }

    @Test
    public void testErrorWhenGoalInputEmpty() {
        // Click save without entering a goal
        onView(withId(R.id.saveGoalButton)).perform(click());

        // Verify error message
        onView(withId(R.id.goalInput))
                .check(matches(hasErrorText("Type your goal here"))); // Matches the error message
    }

    @Test
    public void testValidGoalSubmission() {
        // Enter a goal
        onView(withId(R.id.goalInput)).perform(typeText("Run 5km"), closeSoftKeyboard());

        // Select a category
        onView(withId(R.id.categorySpinner)).perform(click());
        onView(withText("Academic")).perform(click());

        // Click save
        onView(withId(R.id.saveGoalButton)).perform(click());

        // Verify result
        Intent resultData = new Intent();
        resultData.putExtra("goalText", "Study 50min");
        resultData.putExtra("category", "Academic");
    }
}
