package com.example.cp470_assignment_final_iteration;

import android.database.sqlite.SQLiteDatabase;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.core.app.ApplicationProvider;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import com.example.cp470_assignment_final_iteration.Calendar.CalendarDatabaseHelper;
import com.example.cp470_assignment_final_iteration.Calendar.CalendarDeadline;

import java.util.List;

@RunWith(AndroidJUnit4.class)
public class CalendarDatabaseHelperTest {

    @Test
    public void testDatabaseCreation() {
        CalendarDatabaseHelper dbHelper = new CalendarDatabaseHelper(ApplicationProvider.getApplicationContext());
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        assertNotNull(db); // Check if the database is created
        db.close();
    }

    @Test
    public void testAddAndRetrieveDeadline() {
        CalendarDatabaseHelper dbHelper = new CalendarDatabaseHelper(ApplicationProvider.getApplicationContext());

        // Add a test deadline
        CalendarDeadline testDeadline = new CalendarDeadline(
                "Test Deadline", "Work", "2024-12-10", "15:00",
                "Important meeting", "2024-12-09", "14:00");
        dbHelper.addDeadline(testDeadline);

        // Retrieve all deadlines and verify
        List<CalendarDeadline> deadlines = dbHelper.getAllDeadlines();
        assertFalse(deadlines.isEmpty());
        CalendarDeadline retrieved = deadlines.get(0);

        assertEquals("Test Deadline", retrieved.getTitle());
        assertEquals("Work", retrieved.getCategory());
        assertEquals("2024-12-10", retrieved.getDate());
        assertEquals("15:00", retrieved.getTime());
    }
}
