package com.example.cp470_assignment_final_iteration;

import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.espresso.Espresso;
import androidx.test.espresso.matcher.ViewMatchers;

import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;

import com.example.cp470_assignment_final_iteration.Calendar.CalendarMainActivity;

@RunWith(AndroidJUnit4.class)
public class CalendarMainActivityTest {

    @Test
    public void testFragmentSwitching() {
        ActivityScenario.launch(CalendarMainActivity.class);

        // Test Monthly View
        Espresso.onView(ViewMatchers.withId(R.id.btnMonthlyView)).perform(click());
        Espresso.onView(ViewMatchers.withId(R.id.calendarFragmentContainer))
                .check(matches(ViewMatchers.isDisplayed())); // Ensure fragment container is updated

        // Test Weekly View
        Espresso.onView(ViewMatchers.withId(R.id.btnWeeklyView)).perform(click());
        Espresso.onView(ViewMatchers.withId(R.id.calendarFragmentContainer))
                .check(matches(ViewMatchers.isDisplayed()));

        // Test Daily View
        Espresso.onView(ViewMatchers.withId(R.id.btnDailyView)).perform(click());
        Espresso.onView(ViewMatchers.withId(R.id.calendarFragmentContainer))
                .check(matches(ViewMatchers.isDisplayed()));
    }
}
