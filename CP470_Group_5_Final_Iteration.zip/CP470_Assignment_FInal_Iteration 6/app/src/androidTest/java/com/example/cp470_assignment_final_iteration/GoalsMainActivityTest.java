package com.example.cp470_assignment_final_iteration;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.intent.Intents.intended;
import static androidx.test.espresso.intent.matcher.IntentMatchers.hasComponent;
import static androidx.test.espresso.matcher.ViewMatchers.hasErrorText;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

import android.content.Intent;

import androidx.test.espresso.intent.Intents;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.cp470_assignment_final_iteration.Goals.AddGoalActivity;
import com.example.cp470_assignment_final_iteration.Goals.GoalsMainActivity;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;


@RunWith(AndroidJUnit4.class)
public class GoalsMainActivityTest {

    @Rule
    public ActivityScenarioRule<GoalsMainActivity> activityRule =
            new ActivityScenarioRule<>(GoalsMainActivity.class);

    @Test
    public void testRecyclerViewDisplayed() {
        onView(withId(R.id.goalsRecyclerView))
                .check(matches(isDisplayed()));
    }

    @Test
    public void testAddGoalFabNavigatesToAddGoalActivity() {
        Intents.init();
        onView(withId(R.id.addGoalFab)).perform(click());
        intended(hasComponent(AddGoalActivity.class.getName()));
        Intents.release();
    }
}