package com.example.cp470_assignment_final_iteration;

import android.content.Intent;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.action.ViewActions;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.cp470_assignment_final_iteration.Notes.NotesMainActivity;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.Espresso.pressBack;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

@RunWith(AndroidJUnit4.class)
public class NotesMainActivityTest {

    @Rule
    public ActivityScenarioRule<NotesMainActivity> activityRule =
            new ActivityScenarioRule<>(NotesMainActivity.class);

    @Test
    public void testAddNoteButtonOpensNotesTakerActivity() {
        // Check if the add button is displayed and perform a click
        onView(withId(R.id.fab_add)).check(matches(isDisplayed())).perform(click());

        // Verify that NotesTakerActivity is opened
        onView(withId(R.id.toolbar_notes)) // Adjust this to an element in NotesTakerActivity
                .check(matches(isDisplayed()));
    }
}
