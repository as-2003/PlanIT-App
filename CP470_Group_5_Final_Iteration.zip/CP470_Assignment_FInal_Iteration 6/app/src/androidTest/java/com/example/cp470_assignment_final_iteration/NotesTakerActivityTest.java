package com.example.cp470_assignment_final_iteration;

import android.content.Intent;

import androidx.test.core.app.ActivityScenario;
import androidx.test.espresso.Espresso;
import androidx.test.espresso.action.ViewActions;
import androidx.test.espresso.assertion.ViewAssertions;
import androidx.test.espresso.intent.Intents;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.cp470_assignment_final_iteration.Goals.AddGoalActivity;
import com.example.cp470_assignment_final_iteration.Goals.GoalsMainActivity;
import com.example.cp470_assignment_final_iteration.Notes.Models.Notes;
import com.example.cp470_assignment_final_iteration.Notes.NotesTakerActivity;
import com.example.cp470_assignment_final_iteration.Notes.OCR.OCRMainActivity;
import com.example.cp470_assignment_final_iteration.R;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.intent.Intents.intended;
import static androidx.test.espresso.intent.matcher.IntentMatchers.hasComponent;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(AndroidJUnit4.class)
public class NotesTakerActivityTest {

    @Rule
    public ActivityScenarioRule<NotesTakerActivity> activityRule =
            new ActivityScenarioRule<>(NotesTakerActivity.class);

    @Test
    public void testUiElementsLoad() {
        ActivityScenario.launch(NotesTakerActivity.class);

        onView(withId(R.id.editText_title)).check(ViewAssertions.matches(ViewMatchers.isDisplayed()));
        onView(withId(R.id.editText_notes)).check(ViewAssertions.matches(ViewMatchers.isDisplayed()));
        onView(withId(R.id.categorySpinner)).check(ViewAssertions.matches(ViewMatchers.isDisplayed()));
        onView(withId(R.id.imageView_save)).check(ViewAssertions.matches(ViewMatchers.isDisplayed()));
        onView(withId(R.id.cameraFAB)).check(ViewAssertions.matches(ViewMatchers.isDisplayed()));
    }

    @Test
    public void testCameraFABNavigation() {
        Intents.init();
        onView(withId(R.id.cameraFAB)).perform(click());
        intended(hasComponent(OCRMainActivity.class.getName()));
        Intents.release();
    }
}
