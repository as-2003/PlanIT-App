package com.example.cp470_assignment_final_iteration;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.widget.TextView;

import androidx.test.core.app.ActivityScenario;
import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.example.cp470_assignment_final_iteration.Notes.OCR.OCRMainActivity;

import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class OCRMainActivityTest {
    @Test
    public void testCopyToClipboard() {
        // Launch activity
        ActivityScenario<OCRMainActivity> scenario = ActivityScenario.launch(OCRMainActivity.class);

        // Set mock text in TextDataTextView
        String mockText = "Sample OCR Text";
        scenario.onActivity(activity -> {
            TextView textView = activity.findViewById(R.id.TextDataTextView);
            textView.setText(mockText);
        });

        // Perform click on CopyButton
        onView(withId(R.id.CopyButton)).perform(click());

        // Verify clipboard content
        ClipboardManager clipboard = (ClipboardManager) ApplicationProvider.getApplicationContext().getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = clipboard.getPrimaryClip();
        assertNotNull(clip);
        assertEquals(mockText, clip.getItemAt(0).getText().toString());
    }
}
