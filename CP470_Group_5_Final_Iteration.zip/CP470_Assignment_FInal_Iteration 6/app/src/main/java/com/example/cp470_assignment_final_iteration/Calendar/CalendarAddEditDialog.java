package com.example.cp470_assignment_final_iteration.Calendar;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import com.example.cp470_assignment_final_iteration.R;

import java.util.Calendar;
import java.util.Locale;

public class CalendarAddEditDialog  {
    public interface DialogCallback {
        void onSave(CalendarDeadline deadline);
    }

    private Context context;
    private DialogCallback callback;

    public CalendarAddEditDialog(Context context, DialogCallback callback) {
        this.context = context;
        this.callback = callback;
    }

    public void showAddEditDialog(CalendarDeadline deadlineToEdit) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        LayoutInflater inflater = LayoutInflater.from(context);
        View dialogView = inflater.inflate(R.layout.calendar_dialog_add_deadline, null);
        builder.setView(dialogView);

        // Initialize views
        EditText deadlineName = dialogView.findViewById(R.id.deadlineName);
        Spinner categorySpinner = dialogView.findViewById(R.id.categorySpinner);
        Button pickDateButton = dialogView.findViewById(R.id.pickDateButton);
        Button pickTimeButton = dialogView.findViewById(R.id.pickTimeButton);
        Switch notificationSwitch = dialogView.findViewById(R.id.notificationSwitch);
        Button notificationDateButton = dialogView.findViewById(R.id.notificationDateButton);
        Button notificationTimeButton = dialogView.findViewById(R.id.notificationTimeButton);
        EditText comments = dialogView.findViewById(R.id.comments);

        // Hide notification date/time buttons by default
        notificationDateButton.setVisibility(View.GONE);
        notificationTimeButton.setVisibility(View.GONE);


        // Populate fields if editing
        if (deadlineToEdit != null) {
            deadlineName.setText(deadlineToEdit.getTitle());
            pickDateButton.setText(deadlineToEdit.getDate());
            pickTimeButton.setText(deadlineToEdit.getTime());
            comments.setText(deadlineToEdit.getComments());

            String categoryToSelect = deadlineToEdit.getCategory();
            for (int i = 0; i < categorySpinner.getCount(); i++) {
                if (categorySpinner.getItemAtPosition(i).toString().equalsIgnoreCase(categoryToSelect)) {
                    categorySpinner.setSelection(i);
                    break;
                }
            }

            // Handle notification fields
            if (deadlineToEdit.getNotificationDate() != null && deadlineToEdit.getNotificationTime() != null) {
                notificationSwitch.setChecked(true);
                notificationDateButton.setVisibility(View.VISIBLE);
                notificationTimeButton.setVisibility(View.VISIBLE);
                notificationDateButton.setText(deadlineToEdit.getNotificationDate());
                notificationTimeButton.setText(deadlineToEdit.getNotificationTime());
            } else {
                notificationSwitch.setChecked(false);
                notificationDateButton.setVisibility(View.GONE);
                notificationTimeButton.setVisibility(View.GONE);
            }

        }

        // Set up date and time pickers
        pickDateButton.setOnClickListener(v -> showDatePicker(pickDateButton));
        pickTimeButton.setOnClickListener(v -> showTimePicker(pickTimeButton));
        notificationSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            int visibility = isChecked ? View.VISIBLE : View.GONE;
            notificationDateButton.setVisibility(visibility);
            notificationTimeButton.setVisibility(visibility);
        });

        // Set up date and time pickers for notification
        notificationDateButton.setOnClickListener(v -> showDatePicker(notificationDateButton));
        notificationTimeButton.setOnClickListener(v -> showTimePicker(notificationTimeButton));

        builder.setPositiveButton(context.getString(R.string.save), (dialog, id) -> {
            String name = deadlineName.getText().toString().trim();
            String category = categorySpinner.getSelectedItem().toString();
            String date = pickDateButton.getText().toString();
            String time = pickTimeButton.getText().toString();
            String comment = comments.getText().toString();
            String notificationDate = null;
            String notificationTime = null;

            if (notificationSwitch.isChecked()) {
                notificationDate = notificationDateButton.getText().toString();
                notificationTime = notificationTimeButton.getText().toString();
            }

            // Validate inputs
            if (name.isEmpty() || date.equals(context.getString(R.string.pick_date)) || time.equals(context.getString(R.string.pick_time))) {
                Toast.makeText(context, context.getString(R.string.fill_all_fields), Toast.LENGTH_SHORT).show();
                return;
            }

            // If notifications are enabled, validate notification date and time
            if (notificationSwitch.isChecked()) {
                notificationDate = notificationDateButton.getText().toString();
                notificationTime = notificationTimeButton.getText().toString();

                if (notificationDate.equals(context.getString(R.string.pick_notification_date)) || notificationTime.equals(context.getString(R.string.pick_notification_time))) {
                    Toast.makeText(context, context.getString(R.string.fill_all_fields), Toast.LENGTH_SHORT).show();
                    return;
                }
            }

            CalendarDeadline deadline = new CalendarDeadline(name, category, date, time, comment, notificationDate, notificationTime);

            // Schedule notification if enabled
            if (notificationSwitch.isChecked() && notificationDate != null && notificationTime != null) {
                if (canScheduleExactAlarms()) {
                    CalendarNotificationUtils.scheduleNotification(context, deadline, notificationDate, notificationTime);
                } else {
                    requestExactAlarmPermission();
                }
            }

            if (callback != null) callback.onSave(deadline);
        });

        builder.setNegativeButton(context.getString(R.string.cancel), (dialog, id) -> dialog.dismiss());
        builder.create().show();
    }

    private void showDatePicker(Button buttonToUpdate) {
        String currentDate = CalendarDateUtils.getCurrentDate();

        String[] dateParts = currentDate.split("-");
        int year = Integer.parseInt(dateParts[0]);
        int month = Integer.parseInt(dateParts[1]) - 1;
        int day = Integer.parseInt(dateParts[2]);

        new android.app.DatePickerDialog(context, (view, selectedYear, selectedMonth, selectedDay) -> {
            String formattedDate = String.format(Locale.getDefault(), "%d-%02d-%02d", selectedYear, selectedMonth + 1, selectedDay);
            buttonToUpdate.setText(formattedDate);
        }, year, month, day).show();
    }

    private void showTimePicker(Button buttonToUpdate) {
        Calendar calendar = Calendar.getInstance();
        int currentHour = calendar.get(Calendar.HOUR_OF_DAY);
        int currentMinute = calendar.get(Calendar.MINUTE);

        new android.app.TimePickerDialog(context, (view, hourOfDay, minute) -> {
            String formattedTime = String.format(Locale.getDefault(), "%02d:%02d", hourOfDay, minute);
            buttonToUpdate.setText(formattedTime);
        }, currentHour, currentMinute, true).show();
    }

    private boolean canScheduleExactAlarms() {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager != null) {
            return alarmManager.canScheduleExactAlarms();
        }
        return false;
    }

    private void requestExactAlarmPermission() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            Intent intent = new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
            context.startActivity(intent);
        } else {
            Toast.makeText(context, context.getString(R.string.exact_alarms_no_permission), Toast.LENGTH_SHORT).show();
        }
    }
}
