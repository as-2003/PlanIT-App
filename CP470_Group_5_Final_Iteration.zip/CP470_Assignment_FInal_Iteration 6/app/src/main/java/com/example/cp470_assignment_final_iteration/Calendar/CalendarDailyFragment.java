package com.example.cp470_assignment_final_iteration.Calendar;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cp470_assignment_final_iteration.R;

import java.util.ArrayList;
import java.util.List;

public class CalendarDailyFragment extends Fragment {

    private List<CalendarDeadline> allDeadlines;
    private RecyclerView recyclerView;
    private CalendarDeadlinesAdapter adapter;
    private String currentDate;
    private CalendarDatabaseHelper dbHelper;

    // Constructor to accept deadlines list
    public CalendarDailyFragment(List<CalendarDeadline> deadlinesList) {
        this.allDeadlines = deadlinesList;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.calendar_daily_fragment, container, false);

        // Initialize the database helper
        dbHelper = new CalendarDatabaseHelper(requireContext());

        // Initialize all deadlines with fresh data from the database
        allDeadlines = dbHelper.getAllDeadlines();

        // Initialize current date
        currentDate = CalendarDateUtils.getCurrentDate();

        // Set up RecyclerView
        recyclerView = view.findViewById(R.id.dailyDeadlineList);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Create an adapter and attach it to the RecyclerView
        List<CalendarDeadline> dailyDeadlines = getDailyDeadlines();
        adapter = new CalendarDeadlinesAdapter(requireContext(), dailyDeadlines);
        recyclerView.setAdapter(adapter);

        // Set up item click listener for deadlines
        adapter.setOnDeadlineClickListener(this::showDeadlineDetailsPopup);

        adapter.setOnDeleteListener((deadline, position) -> {
            // Delete from the database
            dbHelper.deleteDeadline(deadline.getTitle(), deadline.getDate(), deadline.getTime());

            // Refresh all deadlines from the database
            allDeadlines.clear();
            allDeadlines.addAll(dbHelper.getAllDeadlines());

            // Update the daily deadlines and adapter
            adapter.updateData(getDailyDeadlines());
        });

        // Display the current date
        TextView currentDayText = view.findViewById(R.id.currentDayText);
        currentDayText.setText(currentDate);

        // Handle Previous and Next Day buttons
        Button previousDayBtn = view.findViewById(R.id.previousDayBtn);
        Button nextDayBtn = view.findViewById(R.id.nextDayBtn);

        previousDayBtn.setOnClickListener(v -> {
            currentDate = CalendarDateUtils.getPreviousDay(currentDate);
            updateDayView();
        });

        nextDayBtn.setOnClickListener(v -> {
            currentDate = CalendarDateUtils.getNextDay(currentDate);
            updateDayView();
        });

        return view;
    }

    private void updateDayView() {
        // Reload all deadlines from the database
        allDeadlines.clear();
        allDeadlines.addAll(dbHelper.getAllDeadlines());

        // Filter and update deadlines for the new date
        List<CalendarDeadline> dailyDeadlines = getDailyDeadlines();
        adapter.updateData(dailyDeadlines); // Update the RecyclerView's adapter

        // Update the displayed date
        TextView currentDayText = getView().findViewById(R.id.currentDayText);
        currentDayText.setText(currentDate);
    }

    // Method to filter and return the deadlines for the current date
    private List<CalendarDeadline> getDailyDeadlines() {
        List<CalendarDeadline> dailyDeadlines = new ArrayList<>();
        if (allDeadlines != null) {
            for (CalendarDeadline deadline : allDeadlines) {
                String deadlineDate = deadline.getDate();
                if (deadlineDate.equals(currentDate)) {
                    dailyDeadlines.add(deadline);
                }
            }
        }
        return dailyDeadlines;
    }

    private void showDeadlineDetailsPopup(CalendarDeadline deadline) {
        // Create an AlertDialog to display the details
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(requireContext());
        builder.setTitle(deadline.getTitle());

        // Format the details of the deadline
        String message = requireContext().getString(R.string.category_detail) + deadline.getCategory() + "\n"
                + requireContext().getString(R.string.date_detail) + deadline.getDate() + "\n"
                + requireContext().getString(R.string.time_detail) + deadline.getTime() + "\n"
                + requireContext().getString(R.string.comments_detail) +
                (deadline.getComments().isEmpty() ? requireContext().getString(R.string.no_comments) : deadline.getComments());
        builder.setMessage(message);

        builder.setNegativeButton(requireContext().getString(R.string.edit_button), (dialog, which) -> {
            onEditDeadlineClicked(deadline);
        });

        // Add a button to dismiss the dialog
        builder.setPositiveButton(requireContext().getString(R.string.ok_button), (dialog, which) -> dialog.dismiss());
        builder.create().show();
    }


    private void onEditDeadlineClicked(CalendarDeadline deadline) {
        if (deadline != null) {
            // Open AddEditDialog with prefilled values
            CalendarAddEditDialog dialog = new CalendarAddEditDialog(requireContext(), updatedDeadline -> {
                dbHelper.updateDeadline(deadline.getTitle(), deadline.getDate(), deadline.getTime(), updatedDeadline);

                // Refresh deadlines for the current day
                List<CalendarDeadline> updatedDeadlines = dbHelper.getAllDeadlines();
                allDeadlines.clear();
                allDeadlines.addAll(updatedDeadlines);
                adapter.updateData(getDailyDeadlines());
            });
            dialog.showAddEditDialog(deadline);
        } else {
            Toast.makeText(requireContext(), requireContext().getString(R.string.deadline_not_found), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (dbHelper != null) {
            dbHelper.close();
        }
    }
}