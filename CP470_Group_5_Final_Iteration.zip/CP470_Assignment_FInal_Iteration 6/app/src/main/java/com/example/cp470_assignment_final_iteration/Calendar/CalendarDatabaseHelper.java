package com.example.cp470_assignment_final_iteration.Calendar;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class CalendarDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "new_calendar_deadlines.db"; // New database name
    private static final int DATABASE_VERSION = 1; // Start fresh with version 1

    // Table and columns
    public static final String TABLE_DEADLINES = "deadlines";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_TITLE = "title";
    public static final String COLUMN_CATEGORY = "category";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_TIME = "time";
    public static final String COLUMN_COMMENTS = "comments";
    public static final String COLUMN_NOTIFICATION_DATE = "notification_date";
    public static final String COLUMN_NOTIFICATION_TIME = "notification_time";

    public CalendarDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_DEADLINES + " ("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_TITLE + " TEXT, "
                + COLUMN_CATEGORY + " TEXT, "
                + COLUMN_DATE + " TEXT, "
                + COLUMN_TIME + " TEXT, "
                + COLUMN_COMMENTS + " TEXT, "
                + COLUMN_NOTIFICATION_DATE + " TEXT, "
                + COLUMN_NOTIFICATION_TIME + " TEXT)";
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop the old table and create a new one
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DEADLINES);
        onCreate(db);
    }

    // Save a deadline to the database
    public void addDeadline(CalendarDeadline deadline) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, deadline.getTitle());
        values.put(COLUMN_CATEGORY, deadline.getCategory());
        values.put(COLUMN_DATE, deadline.getDate());
        values.put(COLUMN_TIME, deadline.getTime());
        values.put(COLUMN_COMMENTS, deadline.getComments());
        values.put(COLUMN_NOTIFICATION_DATE, deadline.getNotificationDate());
        values.put(COLUMN_NOTIFICATION_TIME, deadline.getNotificationTime());

        long result = db.insert(TABLE_DEADLINES, null, values);

        if (result != -1) {
            Log.d("CalendarDatabaseHelper", "Deadline added to database: " + deadline.getTitle()
                    + " on " + deadline.getDate() + " at " + deadline.getTime());
        } else {
            Log.e("CalendarDatabaseHelper", "Failed to add deadline to database: " + deadline.getTitle());
        }

        db.close();
    }

    // Load all deadlines from the database
    public List<CalendarDeadline> getAllDeadlines() {
        List<CalendarDeadline> deadlines = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_DEADLINES, null, null, null, null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                String title = cursor.getString(cursor.getColumnIndex(COLUMN_TITLE));
                String category = cursor.getString(cursor.getColumnIndex(COLUMN_CATEGORY));
                String date = cursor.getString(cursor.getColumnIndex(COLUMN_DATE));
                String time = cursor.getString(cursor.getColumnIndex(COLUMN_TIME));
                String comments = cursor.getString(cursor.getColumnIndex(COLUMN_COMMENTS));
                String notificationDate = cursor.getString(cursor.getColumnIndex(COLUMN_NOTIFICATION_DATE));
                String notificationTime = cursor.getString(cursor.getColumnIndex(COLUMN_NOTIFICATION_TIME));

                CalendarDeadline deadline = new CalendarDeadline(title, category, date, time, comments, notificationDate, notificationTime);
                deadlines.add(deadline);
            }
            cursor.close();
        }
        db.close();
        return deadlines;
    }

    // Delete a deadline from the database
    public void deleteDeadline(String title, String date, String time) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Define where clause and arguments
        String whereClause = COLUMN_TITLE + "=? AND " + COLUMN_DATE + "=? AND " + COLUMN_TIME + "=?";
        String[] whereArgs = {title, date, time};

        int deletedRows = db.delete(TABLE_DEADLINES, whereClause, whereArgs);
        Log.d("CalendarDatabaseHelper", "Deleted " + deletedRows + " row(s) for deadline: " + title + " " + date + " " + time);
        db.close();
    }

    // Update an existing deadline in the database
    public void updateDeadline(String oldTitle, String oldDate, String oldTime, CalendarDeadline updatedDeadline) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, updatedDeadline.getTitle());
        values.put(COLUMN_CATEGORY, updatedDeadline.getCategory());
        values.put(COLUMN_DATE, updatedDeadline.getDate());
        values.put(COLUMN_TIME, updatedDeadline.getTime());
        values.put(COLUMN_COMMENTS, updatedDeadline.getComments());
        values.put(COLUMN_NOTIFICATION_DATE, updatedDeadline.getNotificationDate());
        values.put(COLUMN_NOTIFICATION_TIME, updatedDeadline.getNotificationTime());


        // Define where clause and arguments to identify the correct record
        String whereClause = COLUMN_TITLE + "=? AND " + COLUMN_DATE + "=? AND " + COLUMN_TIME + "=?";
        String[] whereArgs = {oldTitle, oldDate, oldTime};

        // Perform the update
        int rowsAffected = db.update(TABLE_DEADLINES, values, whereClause, whereArgs);
        Log.d("CalendarDatabaseHelper", "Updated " + rowsAffected + " row(s) for deadline: " + oldTitle + " " + oldDate + " " + oldTime);

        db.close();
    }
}