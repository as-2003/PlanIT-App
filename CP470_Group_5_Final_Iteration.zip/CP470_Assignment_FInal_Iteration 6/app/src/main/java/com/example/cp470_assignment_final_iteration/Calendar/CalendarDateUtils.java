package com.example.cp470_assignment_final_iteration.Calendar;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class CalendarDateUtils {

    // Method to get the current date as a String in the format "yyyy-MM-dd"
    public static String getCurrentDate() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(calendar.getTime());
    }

    // Method to get the start of the current week
    public static String getStartOfWeek() {
        Calendar calendar = Calendar.getInstance();
        // Set to the first day of the week
        calendar.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(calendar.getTime());
    }

    // Method to get the end of the current week (Saturday or Sunday)
    public static String getEndOfWeek() {
        Calendar calendar = Calendar.getInstance();
        // Set to the first day of the week and add 6 days to get the end of the week
        calendar.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
        calendar.add(Calendar.DAY_OF_WEEK, 6);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(calendar.getTime());
    }

    public static String getNextDay(String date) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date currentDate = sdf.parse(date);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(currentDate);
            calendar.add(Calendar.DATE, 1); // Add 1 day
            return sdf.format(calendar.getTime());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return date;
    }

    public static String getPreviousDay(String date) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date currentDate = sdf.parse(date);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(currentDate);
            calendar.add(Calendar.DATE, -1); // Subtract 1 day
            return sdf.format(calendar.getTime());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return date;
    }

    public static String getNextWeekStart(String date) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date currentDate = sdf.parse(date);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(currentDate);
            calendar.add(Calendar.WEEK_OF_YEAR, 1); // Add 1 week
            calendar.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY); // Start of the week
            return sdf.format(calendar.getTime());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return date;
    }

    public static String getNextWeekEnd(String date) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date currentDate = sdf.parse(date);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(currentDate);
            calendar.add(Calendar.WEEK_OF_YEAR, 1); // Add 1 week
            calendar.set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY); // End of the week
            return sdf.format(calendar.getTime());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return date;
    }

    public static String getPreviousWeekStart(String date) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date currentDate = sdf.parse(date);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(currentDate);
            calendar.add(Calendar.WEEK_OF_YEAR, -1); // Subtract 1 week
            calendar.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY); // Start of the week
            return sdf.format(calendar.getTime());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return date;
    }

    public static String getPreviousWeekEnd(String date) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date currentDate = sdf.parse(date);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(currentDate);
            calendar.add(Calendar.WEEK_OF_YEAR, -1); // Subtract 1 week
            calendar.set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY); // End of the week
            return sdf.format(calendar.getTime());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return date;
    }


}
