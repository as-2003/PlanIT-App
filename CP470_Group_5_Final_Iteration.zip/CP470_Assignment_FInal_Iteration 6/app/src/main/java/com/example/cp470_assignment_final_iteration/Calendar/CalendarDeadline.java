package com.example.cp470_assignment_final_iteration.Calendar;

public class CalendarDeadline {
    private String title;
    private String category;
    private String date;
    private String time;
    private String comments;
    private String notificationDate;
    private String notificationTime;


    // Constructor
    public CalendarDeadline(String title, String category, String date, String time, String comments, String notificationDate, String notificationTime) {
        this.title = title;
        this.category = category;
        this.date = date;
        this.time = time;
        this.comments = comments;
        this.notificationDate = notificationDate;
        this.notificationTime = notificationTime;
    }

    // Getters
    public String getTitle() {
        return title;
    }

    public String getCategory() {
        return category;
    }

    public String getNotificationDate() {
        return notificationDate;
    }

    public String getNotificationTime() {
        return notificationTime;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public String getComments() {
        return comments;
    }

    // Setters
    public void setTitle(String title) {
        this.title = title;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public void setNotificationDate(String notificationDate) {
        this.notificationDate = notificationDate;
    }

    public void setNotificationTime(String notificationTime) {
        this.notificationTime = notificationTime;
    }
}
