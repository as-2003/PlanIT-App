package com.example.cp470_assignment_final_iteration.Calendar;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cp470_assignment_final_iteration.R;
import com.google.android.material.card.MaterialCardView;

import java.util.List;

public class CalendarDeadlinesAdapter extends RecyclerView.Adapter<CalendarDeadlinesAdapter.DeadlineViewHolder> {

    private List<CalendarDeadline> deadlines;
    private Context context;
    private OnDeadlineClickListener onDeadlineClickListener;
    private OnDeleteListener deleteListener;
    private CalendarDatabaseHelper dbHelper;

    // Constructor
    public CalendarDeadlinesAdapter(Context context, List<CalendarDeadline> deadlines) {
        this.context = context;
        this.deadlines = deadlines;
        this.dbHelper = new CalendarDatabaseHelper(context);
    }

    // Method to update the data in the adapter
    public void updateData(List<CalendarDeadline> newDeadlines) {
        this.deadlines.clear();
        this.deadlines.addAll(newDeadlines);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public DeadlineViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.calendar_item_deadline, parent, false);
        return new DeadlineViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DeadlineViewHolder holder, int position) {
        CalendarDeadline deadline = deadlines.get(position);
        holder.deadlineTitleTextView.setText(deadline.getTitle());

        // Change the card color based on the category
        String category = deadline.getCategory();
        String[] categories = holder.itemView.getContext().getResources().getStringArray(R.array.categories);
        int color = 0;

        // Assign colors based on the category index in the array
        if (category.equalsIgnoreCase(categories[0])) { // Personal
            color = ContextCompat.getColor(holder.itemView.getContext(), R.color.yellow);
        } else if (category.equalsIgnoreCase(categories[1])) { // Academic
            color = ContextCompat.getColor(holder.itemView.getContext(), R.color.purple);
        } else if (category.equalsIgnoreCase(categories[2])) { // Work
            color = ContextCompat.getColor(holder.itemView.getContext(), R.color.blue);
        } else if (category.equalsIgnoreCase(categories[3])) { // Other
            color = ContextCompat.getColor(holder.itemView.getContext(), R.color.green);
        }

        holder.materialCardView.setCardBackgroundColor(color);

        // Set up item click listener
        holder.itemView.setOnClickListener(v -> {
            if (onDeadlineClickListener != null) {
                onDeadlineClickListener.onDeadlineClick(deadline);
            }
        });

        // Long-press listener for deletion
        holder.itemView.setOnLongClickListener(v -> {
            new AlertDialog.Builder(context)
                    .setTitle(context.getString(R.string.delete_deadline_title))
                    .setMessage(context.getString(R.string.delete_deadline_message))
                    .setPositiveButton(context.getString(R.string.yes_button), (dialog, which) -> {
                        // If the user confirms, trigger the delete listener
                        if (deleteListener != null) {
                            deleteListener.onDeleteConfirmed(deadline, position);
                        }
                        dialog.dismiss();
                    })
                    .setNegativeButton(context.getString(R.string.no_button), (dialog, which) -> dialog.dismiss())
                    .show();

            return true;
        });

    }

    @Override
    public int getItemCount() {
        return deadlines.size();
    }

    // ViewHolder class
    public static class DeadlineViewHolder extends RecyclerView.ViewHolder {
        TextView deadlineTitleTextView;
        MaterialCardView materialCardView;


        public DeadlineViewHolder(View itemView) {
            super(itemView);
            deadlineTitleTextView = itemView.findViewById(R.id.deadlineText);
            materialCardView = (MaterialCardView) itemView;
        }
    }

    // Interface for click action
    public interface OnDeadlineClickListener {
        void onDeadlineClick(CalendarDeadline deadline);
    }

    public void setOnDeadlineClickListener(OnDeadlineClickListener listener) {
        this.onDeadlineClickListener = listener;
    }

    // Interface for delete confirmation
    public interface OnDeleteListener {
        void onDeleteConfirmed(CalendarDeadline deadline, int position);
    }

    public void setOnDeleteListener(OnDeleteListener listener) {
        this.deleteListener = listener;
    }

    // Method to remove a deadline from the list and update RecyclerView
    public void removeDeadline(CalendarDeadline deadline, int position) {
        dbHelper.deleteDeadline(deadline.getTitle(), deadline.getDate(), deadline.getTime());
        deadlines.remove(position);

        // Notify the adapter
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, deadlines.size());
    }

    // Method to refresh data from the database (after deletion)
    public void refreshDataFromDatabase() {
        List<CalendarDeadline> updatedDeadlines = dbHelper.getAllDeadlines();
        updateData(updatedDeadlines); // Update adapter's data
    }
}
