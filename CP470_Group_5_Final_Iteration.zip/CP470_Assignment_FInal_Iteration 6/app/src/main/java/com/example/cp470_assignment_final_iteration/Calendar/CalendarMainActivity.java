package com.example.cp470_assignment_final_iteration.Calendar;

import android.content.Intent; // Added for Help and About functionality
import android.os.Bundle;
import android.util.Log;
import android.view.Menu; // Added for Help and About menu
import android.view.MenuItem; // Added for Help and About menu
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.example.cp470_assignment_final_iteration.AboutActivity; // Added for AboutActivity
import com.example.cp470_assignment_final_iteration.Goals.GoalsMainActivity;
import com.example.cp470_assignment_final_iteration.HelpActivity;  // Added for HelpActivity
import com.example.cp470_assignment_final_iteration.Notes.NotesMainActivity;
import com.example.cp470_assignment_final_iteration.R;
import com.example.cp470_assignment_final_iteration.Tasks.TaskMainActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class CalendarMainActivity extends AppCompatActivity {

    private FloatingActionButton fabAddDeadline;
    private List<CalendarDeadline> deadlinesList;
    private CalendarDeadlinesAdapter calendarDeadlinesAdapter;
    private CalendarDatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calendar_activity_main);

        fabAddDeadline = findViewById(R.id.fab_add_deadline);
        deadlinesList = new ArrayList<>();
        calendarDeadlinesAdapter = new CalendarDeadlinesAdapter(this, deadlinesList);
        databaseHelper = new CalendarDatabaseHelper(this);

        CalendarNotificationUtils.createNotificationChannel(this);

        loadDeadlines();
        loadFragment(new CalendarMonthlyFragment(deadlinesList));

        fabAddDeadline.setOnClickListener(v -> {
            CalendarAddEditDialog dialog = new CalendarAddEditDialog(this, newDeadline -> saveDeadline(newDeadline));
            dialog.showAddEditDialog(null);
        });

        Button btnMonthlyView = findViewById(R.id.btnMonthlyView);
        Button btnWeeklyView = findViewById(R.id.btnWeeklyView);
        Button btnDailyView = findViewById(R.id.btnDailyView);

        btnMonthlyView.setOnClickListener(v -> loadFragment(new CalendarMonthlyFragment(deadlinesList)));
        btnWeeklyView.setOnClickListener(v -> loadFragment(new CalendarWeeklyFragment(deadlinesList)));
        btnDailyView.setOnClickListener(v -> loadFragment(new CalendarDailyFragment(deadlinesList)));
    }

    private void loadDeadlines() {
        deadlinesList.clear();
        deadlinesList.addAll(databaseHelper.getAllDeadlines());
        calendarDeadlinesAdapter.notifyDataSetChanged();
    }

    private void saveDeadline(CalendarDeadline newDeadline) {
        databaseHelper.addDeadline(newDeadline);
        deadlinesList.add(newDeadline);
        calendarDeadlinesAdapter.notifyDataSetChanged();
        refreshFragmentData();
        Toast.makeText(this, getString(R.string.deadline_added_message), Toast.LENGTH_SHORT).show();
    }

    private void refreshFragmentData() {
        FragmentManager fm = getSupportFragmentManager();
        Fragment currentFragment = fm.findFragmentById(R.id.calendarFragmentContainer);
        if (currentFragment instanceof CalendarMonthlyFragment) {
            ((CalendarMonthlyFragment) currentFragment).refreshAllDeadlines();
        }
    }

    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.calendarFragmentContainer, fragment)
                .commit();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("ActivityLifecycle", "MainActivity onResume");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.navigation_menu, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem currentItem = menu.findItem(R.id.calendar);
        if (currentItem != null) {
            currentItem.setVisible(false);
        }
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.help) {
            Intent helpMenu = new Intent(this, HelpActivity.class);
            startActivity(helpMenu);
        } else if (item.getItemId() == R.id.about) {
            Intent helpMenu = new Intent(this, AboutActivity.class);
            startActivity(helpMenu);
        } else if (item.getItemId() == R.id.calendar) {
            Intent helpMenu = new Intent(this, CalendarMainActivity.class);
            startActivity(helpMenu);
        } else if (item.getItemId() == R.id.notes) {
            Intent helpMenu = new Intent(this, NotesMainActivity.class);
            startActivity(helpMenu);
        } else if (item.getItemId() == R.id.tasks) {
            Intent helpMenu = new Intent(this, TaskMainActivity.class);
            startActivity(helpMenu);
        } else if (item.getItemId() == R.id.goals) {
            Intent helpMenu = new Intent(this, GoalsMainActivity.class);
            startActivity(helpMenu);
        }
        return super.onOptionsItemSelected(item);
    }
}
