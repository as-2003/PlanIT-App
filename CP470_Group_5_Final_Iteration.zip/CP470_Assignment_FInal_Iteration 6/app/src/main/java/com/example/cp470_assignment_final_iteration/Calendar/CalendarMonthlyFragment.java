package com.example.cp470_assignment_final_iteration.Calendar;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CalendarView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cp470_assignment_final_iteration.R;

import java.util.ArrayList;
import java.util.List;

public class CalendarMonthlyFragment extends Fragment {

    private List<CalendarDeadline> allDeadlines;
    private RecyclerView recyclerView;
    private CalendarDeadlinesAdapter adapter;
    private CalendarDatabaseHelper dbHelper;
    private String selectedDate = CalendarDateUtils.getCurrentDate();

    public CalendarMonthlyFragment(List<CalendarDeadline> deadlinesList) {
        this.allDeadlines = deadlinesList;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.calendar_monthly_fragment, container, false);

        dbHelper = new CalendarDatabaseHelper(requireContext());
        allDeadlines = dbHelper.getAllDeadlines();

        // Set up RecyclerView
        recyclerView = view.findViewById(R.id.deadlineList);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Create adapter and attach to RecyclerView
        List<CalendarDeadline> initialDeadlines = filterDeadlinesForDate(selectedDate);
        adapter = new CalendarDeadlinesAdapter(requireContext(), initialDeadlines);
        recyclerView.setAdapter(adapter);

        // Set up item click and delete listeners
        adapter.setOnDeadlineClickListener(this::showDeadlineDetailsPopup);
        adapter.setOnDeleteListener((deadline, position) -> {
            dbHelper.deleteDeadline(deadline.getTitle(), deadline.getDate(), deadline.getTime());
            refreshAllDeadlines(); // Refresh deadlines for the selected date
        });

        // Set up CalendarView
        CalendarView calendarView = view.findViewById(R.id.monthlyCalendarView);
        calendarView.setOnDateChangeListener((view1, year, month, dayOfMonth) -> {
            selectedDate = String.format("%d-%02d-%02d", year, month + 1, dayOfMonth);
            updateDeadlinesForSelectedDate(selectedDate);
        });

        return view;
    }

    public void refreshAllDeadlines() {
        allDeadlines = dbHelper.getAllDeadlines(); // Refresh from DB
        updateDeadlinesForSelectedDate(selectedDate); // Use the selected date
    }

    private void updateDeadlinesForSelectedDate(String date) {
        List<CalendarDeadline> filteredDeadlines = filterDeadlinesForDate(date);
        adapter.updateData(filteredDeadlines);
    }

    private List<CalendarDeadline> filterDeadlinesForDate(String date) {
        List<CalendarDeadline> filteredDeadlines = new ArrayList<>();
        if (allDeadlines != null) {
            for (CalendarDeadline deadline : allDeadlines) {
                if (deadline.getDate().equals(date)) {
                    filteredDeadlines.add(deadline);
                }
            }
        }
        return filteredDeadlines;
    }


    private void showDeadlineDetailsPopup(CalendarDeadline deadline) {
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(requireContext());
        builder.setTitle(deadline.getTitle());

        // Format the details of the deadline
        String message = requireContext().getString(R.string.category_detail) + deadline.getCategory() + "\n"
                + requireContext().getString(R.string.date_detail) + deadline.getDate() + "\n"
                + requireContext().getString(R.string.time_detail) + deadline.getTime() + "\n"
                + requireContext().getString(R.string.comments_detail) +
                (deadline.getComments().isEmpty() ? requireContext().getString(R.string.no_comments) : deadline.getComments());
        builder.setMessage(message);

        builder.setNegativeButton(requireContext().getString(R.string.edit_button), (dialog, which) -> {
            onEditDeadlineClicked(deadline);
        });

        // Add a button to dismiss the dialog
        builder.setPositiveButton(requireContext().getString(R.string.ok_button), (dialog, which) -> dialog.dismiss());
        builder.create().show();
    }

    private void onEditDeadlineClicked(CalendarDeadline deadline) {
        if (deadline != null) {
            CalendarAddEditDialog dialog = new CalendarAddEditDialog(requireContext(), updatedDeadline -> {
                dbHelper.updateDeadline(deadline.getTitle(), deadline.getDate(), deadline.getTime(), updatedDeadline);
                refreshAllDeadlines();
            });
            dialog.showAddEditDialog(deadline);
        } else {
            Toast.makeText(requireContext(), requireContext().getString(R.string.deadline_not_found), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (dbHelper != null) {
            dbHelper.close();
        }
    }
}
