package com.example.cp470_assignment_final_iteration.Calendar;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.widget.Toast;

import com.example.cp470_assignment_final_iteration.R;

import java.util.Calendar;

public class CalendarNotificationUtils {

    public static void createNotificationChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            String channelId = "deadline_channel";
            String channelName = "Deadline Notifications";
            String channelDescription = "Notifies users of upcoming deadlines";
            int importance = NotificationManager.IMPORTANCE_HIGH;

            NotificationChannel channel = new NotificationChannel(channelId, channelName, importance);
            channel.setDescription(channelDescription);

            NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
    }

    public static void scheduleNotification(Context context, CalendarDeadline deadline, String notificationDate, String notificationTime) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

        if (alarmManager == null) {
            Toast.makeText(context, context.getString(R.string.exact_alarms_no_permission), Toast.LENGTH_SHORT).show();
            return;
        }

        // Check for SCHEDULE_EXACT_ALARM permission
        if (!alarmManager.canScheduleExactAlarms()) {
            Toast.makeText(context, context.getString(R.string.exact_alarms_no_permission), Toast.LENGTH_LONG).show();
            requestExactAlarmPermission(context);
            return;
        }

        // Parse notification date and time
        String[] dateParts = notificationDate.split("-");
        String[] timeParts = notificationTime.split(":");
        int year = Integer.parseInt(dateParts[0]);
        int month = Integer.parseInt(dateParts[1]) - 1;
        int day = Integer.parseInt(dateParts[2]);
        int hour = Integer.parseInt(timeParts[0]);
        int minute = Integer.parseInt(timeParts[1]);

        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, day, hour, minute, 0);
        long notificationTimeMillis = calendar.getTimeInMillis();

        // Create intent for notification
        Intent intent = new Intent(context, CalendarNotificationReceiver.class);
        intent.putExtra("title", deadline.getTitle());
        intent.putExtra("description", context.getString(R.string.notification_message));
        intent.putExtra("notificationId", deadline.hashCode());

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                deadline.hashCode(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        // Schedule the exact alarm
        try {
            alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    notificationTimeMillis,
                    pendingIntent
            );
            Toast.makeText(context, context.getString(R.string.notification_toast_message), Toast.LENGTH_SHORT).show();
        } catch (SecurityException e) {
            Toast.makeText(context, context.getString(R.string.exact_alarms_no_permission), Toast.LENGTH_SHORT).show();
        }
    }

    private static void requestExactAlarmPermission(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            Intent intent = new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
            context.startActivity(intent);
        } else {
            Toast.makeText(context, context.getString(R.string.exact_alarms_no_permission), Toast.LENGTH_SHORT).show();
        }
    }
}
