package com.example.cp470_assignment_final_iteration.Calendar;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cp470_assignment_final_iteration.R;

import java.util.ArrayList;
import java.util.List;

public class CalendarWeeklyFragment extends Fragment {

    private List<CalendarDeadline> allDeadlines;
    private RecyclerView recyclerView;
    private CalendarDeadlinesAdapter adapter;
    private String currentStartOfWeek;
    private String currentEndOfWeek;
    private CalendarDatabaseHelper dbHelper;

    // Constructor to accept deadlines list
    public CalendarWeeklyFragment(List<CalendarDeadline> deadlinesList) {
        this.allDeadlines = deadlinesList;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.calendar_weekly_fragment, container, false);

        dbHelper = new CalendarDatabaseHelper(requireContext());

        // Initialize allDeadlines with fresh data
        allDeadlines = dbHelper.getAllDeadlines();

        // Initialize current week's start and end date
        currentStartOfWeek = CalendarDateUtils.getStartOfWeek();
        currentEndOfWeek = CalendarDateUtils.getEndOfWeek();

        // Set up RecyclerView
        recyclerView = view.findViewById(R.id.weeklyDeadlineList);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Create an adapter and attach it to the RecyclerView
        List<CalendarDeadline> weeklyDeadlines = getWeeklyDeadlines();
        adapter = new CalendarDeadlinesAdapter(requireContext(), weeklyDeadlines);
        recyclerView.setAdapter(adapter);

        // Set up item click listener for deadlines
        adapter.setOnDeadlineClickListener(this::showDeadlineDetailsPopup);

        adapter.setOnDeleteListener((deadline, position) -> {
            // Delete from the database
            dbHelper.deleteDeadline(deadline.getTitle(), deadline.getDate(), deadline.getTime());

            // Refresh deadlines from the database and update the adapter
            refreshAllDeadlines(currentStartOfWeek, currentEndOfWeek);
        });

        // Set the current week text
        TextView currentWeekText = view.findViewById(R.id.currentWeekText);
        currentWeekText.setText(currentStartOfWeek + " - " + currentEndOfWeek);

        // Handle Previous and Next Week buttons
        Button previousWeekBtn = view.findViewById(R.id.previousWeekBtn);
        Button nextWeekBtn = view.findViewById(R.id.nextWeekBtn);

        previousWeekBtn.setOnClickListener(v -> {
            currentStartOfWeek = CalendarDateUtils.getPreviousWeekStart(currentStartOfWeek);
            currentEndOfWeek = CalendarDateUtils.getPreviousWeekEnd(currentEndOfWeek);
            updateWeekView();
        });

        nextWeekBtn.setOnClickListener(v -> {
            currentStartOfWeek = CalendarDateUtils.getNextWeekStart(currentStartOfWeek);
            currentEndOfWeek = CalendarDateUtils.getNextWeekEnd(currentEndOfWeek);
            updateWeekView();
        });

        return view;
    }

    private void updateWeekView() {
        refreshAllDeadlines(currentStartOfWeek, currentEndOfWeek); // Refresh and filter for the current week
        TextView currentWeekText = getView().findViewById(R.id.currentWeekText);
        currentWeekText.setText(currentStartOfWeek + " - " + currentEndOfWeek);
    }


    private void refreshAllDeadlines(String startOfWeek, String endOfWeek) {
        // Reload all deadlines from the database
        allDeadlines.clear();
        allDeadlines.addAll(dbHelper.getAllDeadlines());

        // Update the adapter with filtered weekly deadlines
        List<CalendarDeadline> weeklyDeadlines = filterDeadlinesForWeek(startOfWeek, endOfWeek);
        adapter.updateData(weeklyDeadlines);
    }

    private List<CalendarDeadline> filterDeadlinesForWeek(String startOfWeek, String endOfWeek) {
        List<CalendarDeadline> weeklyDeadlines = new ArrayList<>();
        for (CalendarDeadline deadline : allDeadlines) {
            String deadlineDate = deadline.getDate(); // Assuming CalendarDeadline has a getDate() method
            if (deadlineDate.compareTo(startOfWeek) >= 0 && deadlineDate.compareTo(endOfWeek) <= 0) {
                weeklyDeadlines.add(deadline);
            }
        }
        return weeklyDeadlines;
    }


    // Method to filter and return the deadlines for the current week
    private List<CalendarDeadline> getWeeklyDeadlines() {
        List<CalendarDeadline> weeklyDeadlines = new ArrayList<>();
        if (allDeadlines != null) {
            for (CalendarDeadline deadline : allDeadlines) {
                String deadlineDate = deadline.getDate(); // assuming CalendarDeadline has a method getDate()
                if (isWithinWeek(deadlineDate)) {
                    weeklyDeadlines.add(deadline);
                }
            }
        }
        return weeklyDeadlines;
    }

    // Helper method to check if the deadline date is within the current week range
    private boolean isWithinWeek(String date) {
        return date.compareTo(currentStartOfWeek) >= 0 && date.compareTo(currentEndOfWeek) <= 0;
    }

    private void showDeadlineDetailsPopup(CalendarDeadline deadline) {
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(requireContext());
        builder.setTitle(deadline.getTitle());

        // Format the details of the deadline
        String message = requireContext().getString(R.string.category_detail) + deadline.getCategory() + "\n"
                + requireContext().getString(R.string.date_detail) + deadline.getDate() + "\n"
                + requireContext().getString(R.string.time_detail) + deadline.getTime() + "\n"
                + requireContext().getString(R.string.comments_detail) +
                (deadline.getComments().isEmpty() ? requireContext().getString(R.string.no_comments) : deadline.getComments());
        builder.setMessage(message);

        builder.setNegativeButton(requireContext().getString(R.string.edit_button), (dialog, which) -> {
            onEditDeadlineClicked(deadline);
        });

        // Add a button to dismiss the dialog
        builder.setPositiveButton(requireContext().getString(R.string.ok_button), (dialog, which) -> dialog.dismiss());
        builder.create().show();
    }

    private void onEditDeadlineClicked(CalendarDeadline deadline) {
        if (deadline != null) {
            // Open AddEditDialog with prefilled values
            CalendarAddEditDialog dialog = new CalendarAddEditDialog(requireContext(), updatedDeadline -> {
                dbHelper.updateDeadline(deadline.getTitle(), deadline.getDate(), deadline.getTime(), updatedDeadline);

                // Refresh deadlines for the current week
                List<CalendarDeadline> updatedDeadlines = dbHelper.getAllDeadlines();
                allDeadlines.clear();
                allDeadlines.addAll(updatedDeadlines);
                adapter.updateData(getWeeklyDeadlines());
            });
            dialog.showAddEditDialog(deadline);
        } else {
            Toast.makeText(requireContext(), requireContext().getString(R.string.deadline_not_found), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }
}