package com.example.cp470_assignment_final_iteration.Dashboard;

import android.content.Intent; // Added for Help and About functionality
import android.os.Bundle;
import android.util.Log;
import android.view.Menu; // Added for Help and About menu
import android.view.MenuItem; // Added for Help and About menu
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.cp470_assignment_final_iteration.AboutActivity; // Added for AboutActivity
import com.example.cp470_assignment_final_iteration.HelpActivity;  // Added for HelpActivity
import com.example.cp470_assignment_final_iteration.Calendar.CalendarMainActivity;
import com.example.cp470_assignment_final_iteration.Goals.GoalsMainActivity;
import com.example.cp470_assignment_final_iteration.Notes.NotesMainActivity;
import com.example.cp470_assignment_final_iteration.R;
import com.example.cp470_assignment_final_iteration.Tasks.TaskMainActivity;

import java.util.List;

public class DashboardMainActivity extends AppCompatActivity {

    private Button notesGOTO, calendarGOTO, goalsGOTO, tasksGOTO;
    private TextView welcomeText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dashboard_activity_main);

        // Retrieve the user's name from the Intent
        Intent intent = getIntent();
        String userName = intent.getStringExtra("username");
        if (userName == null || userName.isEmpty()) {
            userName = "User"; // Default to "User" if no name is provided
        }

        // Set up the welcome text
        welcomeText = findViewById(R.id.welcomeText);
        String welcomeMessage = getString(R.string.welcome_user, userName); // Localized welcome message
        welcomeText.setText(welcomeMessage);

        // Logo Animation (Sliding in from Top)
        ImageView appLogo = findViewById(R.id.appLogo);
        Animation logoAnimation = AnimationUtils.loadAnimation(this, R.anim.rocket_fly);
        appLogo.startAnimation(logoAnimation);

        // Navigation Buttons
        notesGOTO = findViewById(R.id.notesGOTO);
        notesGOTO.setOnClickListener(v -> {
            Log.d("DashboardMainActivity", "Notes button clicked");
            Intent notesIntent = new Intent(DashboardMainActivity.this, NotesMainActivity.class);
            startActivity(notesIntent);
        });

        calendarGOTO = findViewById(R.id.calendarGOTO);
        calendarGOTO.setOnClickListener(v -> {
            Log.d("DashboardMainActivity", "Calendar button clicked");
            Intent calendarIntent = new Intent(DashboardMainActivity.this, CalendarMainActivity.class);
            startActivity(calendarIntent);
        });

        goalsGOTO = findViewById(R.id.goalsGOTO);
        goalsGOTO.setOnClickListener(v -> {
            Log.d("DashboardMainActivity", "Goals button clicked");
            Intent goalsIntent = new Intent(DashboardMainActivity.this, GoalsMainActivity.class);
            startActivity(goalsIntent);
        });

        tasksGOTO = findViewById(R.id.tasksGOTO);
        tasksGOTO.setOnClickListener(v -> {
            Log.d("DashboardMainActivity", "Tasks button clicked");
            Intent tasksIntent = new Intent(DashboardMainActivity.this, TaskMainActivity.class);
            startActivity(tasksIntent);
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu for Help and About
        getMenuInflater().inflate(R.menu.navigation_menu, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem item1 = menu.findItem(R.id.calendar);
        MenuItem item2 = menu.findItem(R.id.tasks);
        MenuItem item3 = menu.findItem(R.id.notes);
        MenuItem item4 = menu.findItem(R.id.goals);
        if (item1 != null) {
            item1.setVisible(false);
        }
        if (item2 != null) {
            item2.setVisible(false);
        }
        if (item3 != null) {
            item3.setVisible(false);
        }
        if (item4 != null) {
            item4.setVisible(false);
        }
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle Help and About menu item selection
        if (item.getItemId() == R.id.help) {
            Intent helpMenu = new Intent(this, HelpActivity.class);
            startActivity(helpMenu);
        } else if (item.getItemId() == R.id.about) {
            Intent helpMenu = new Intent(this, AboutActivity.class);
            startActivity(helpMenu);
        } else if (item.getItemId() == R.id.calendar) {
            Intent helpMenu = new Intent(this, CalendarMainActivity.class);
            startActivity(helpMenu);
        } else if (item.getItemId() == R.id.notes) {
            Intent helpMenu = new Intent(this, NotesMainActivity.class);
            startActivity(helpMenu);
        } else if (item.getItemId() == R.id.tasks) {
            Intent helpMenu = new Intent(this, TaskMainActivity.class);
            startActivity(helpMenu);
        } else if (item.getItemId() == R.id.goals) {
            Intent helpMenu = new Intent(this, GoalsMainActivity.class);
            startActivity(helpMenu);
        }
        return super.onOptionsItemSelected(item);
    }
}
