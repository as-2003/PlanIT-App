package com.example.cp470_assignment_final_iteration.Goals;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import com.example.cp470_assignment_final_iteration.R;

public class AddGoalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.goals_add_goal_activity);

        // UI Elements
        EditText goalInput = findViewById(R.id.goalInput);
        Spinner categorySpinner = findViewById(R.id.categorySpinner);
        Button saveGoalButton = findViewById(R.id.saveGoalButton);

        // Set up Spinner with default styling
        String[] categories = getResources().getStringArray(R.array.categories);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categories);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(adapter);

        // Handle save button click
        saveGoalButton.setOnClickListener(v -> {
            String goalText = goalInput.getText().toString().trim();
            String category = categorySpinner.getSelectedItem().toString();

            if (!goalText.isEmpty()) {
                Intent resultIntent = new Intent();
                resultIntent.putExtra("goalText", goalText);
                resultIntent.putExtra("category", category);
                setResult(RESULT_OK, resultIntent);
                finish();
            } else {
                goalInput.setError(getString(R.string.type_your_goal_here));
            }
        });
    }
}
