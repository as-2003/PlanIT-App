package com.example.cp470_assignment_final_iteration.Goals;

public class Goal {
    private String goalText;
    private String category;
    private int priority;
    private int currentProgress;

    public Goal(String goalText, String category, int priority) {
        this.goalText = goalText;
        this.category = category;
        this.priority = priority;
        this.currentProgress = 0;
    }

    // Getters and Setters
    public String getGoalText() {
        return goalText;
    }

    public void setGoalText(String goalText) {
        this.goalText = goalText;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public int getCurrentProgress() {
        return currentProgress;
    }

    public void setCurrentProgress(int currentProgress) {
        this.currentProgress = currentProgress;
    }
}
