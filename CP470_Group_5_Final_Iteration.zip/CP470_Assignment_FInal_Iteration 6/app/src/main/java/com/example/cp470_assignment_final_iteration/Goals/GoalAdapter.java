package com.example.cp470_assignment_final_iteration.Goals;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cp470_assignment_final_iteration.R;

import java.util.List;

public class GoalAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private final Context context;
    private final OnDeleteCallback onDelete;
    private final OnStartDragListener onStartDragListener;
    private List<Object> data;

    private static final int TYPE_CATEGORY = 0;
    private static final int TYPE_GOAL = 1;

    public interface OnDeleteCallback {
        void onDelete(int position, Object item);
    }

    public interface OnStartDragListener {
        void onStartDrag(RecyclerView.ViewHolder viewHolder);
    }

    public GoalAdapter(Context context, List<Object> data, OnDeleteCallback onDelete, OnStartDragListener onStartDragListener) {
        this.context = context;
        this.data = data;
        this.onDelete = onDelete;
        this.onStartDragListener = onStartDragListener;
    }

    @Override
    public int getItemViewType(int position) {
        return (data.get(position) instanceof Goal) ? TYPE_GOAL : TYPE_CATEGORY;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == TYPE_CATEGORY) {
            View view = LayoutInflater.from(context).inflate(R.layout.goal_category_item, parent, false);
            return new CategoryViewHolder(view);
        } else {
            View view = LayoutInflater.from(context).inflate(R.layout.goals_item, parent, false);
            return new GoalViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof CategoryViewHolder) {
            CategoryViewHolder categoryHolder = (CategoryViewHolder) holder;
            String category = (String) data.get(position);
            categoryHolder.categoryText.setText(category);

            // Set background color based on category
            int backgroundColor = getCategoryColor(category);
            categoryHolder.categoryText.setBackgroundColor(backgroundColor);
            categoryHolder.categoryText.setTextColor(context.getResources().getColor(R.color.white));
        } else if (holder instanceof GoalViewHolder) {
            Goal goal = (Goal) data.get(position);
            GoalViewHolder goalHolder = (GoalViewHolder) holder;

            // Add "Goal #<priority>: " prefix dynamically based on priority
            String goalText = context.getString(R.string.goal_number_prefix) + goal.getPriority() + ": " + goal.getGoalText();
            goalHolder.goalText.setText(goalText);

            // Set text color and progress bar color based on category
            int categoryColor = getCategoryColor(goal.getCategory());
            goalHolder.goalText.setTextColor(categoryColor);
            goalHolder.progressBar.setProgressTintList(ColorStateList.valueOf(categoryColor));
            goalHolder.progressBar.setProgress(goal.getCurrentProgress());

            // Update progress text
            String progressText = context.getString(R.string.progress_completed, goal.getCurrentProgress());
            goalHolder.progressText.setText(progressText);

            // Handle click to show options dialog
            goalHolder.itemView.setOnClickListener(v -> showOptionsDialog(goal, position));

            // Drag handle logic
            goalHolder.reorderHandle.setOnTouchListener((v, event) -> {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    if (onStartDragListener != null) {
                        onStartDragListener.onStartDrag(holder);
                    }
                }
                return false;
            });
        }
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public void updateData(List<Object> data) {
        this.data = data;
        notifyDataSetChanged();
    }

    private int getCategoryColor(String category) {
        switch (category.toLowerCase()) {
            case "work":
            case "travail": // French
                return context.getResources().getColor(R.color.blue);
            case "academic":
            case "acadÃ©mique": // French
                return context.getResources().getColor(R.color.purple);
            case "personal":
            case "personnel": // French
                return context.getResources().getColor(R.color.yellow);
            case "other":
            case "autre": // French
                return context.getResources().getColor(R.color.green);
            default:
                return context.getResources().getColor(R.color.gray);
        }
    }

    private void showOptionsDialog(Goal goal, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        View dialogView = LayoutInflater.from(context).inflate(R.layout.goals_dialog_options, null);
        builder.setView(dialogView);

        TextView updateProgress = dialogView.findViewById(R.id.updateProgress);
        TextView editGoal = dialogView.findViewById(R.id.editGoal);
        TextView deleteGoal = dialogView.findViewById(R.id.deleteGoal);
        TextView cancelButton = dialogView.findViewById(R.id.cancelButton);

        AlertDialog dialog = builder.create();

        updateProgress.setOnClickListener(v -> {
            if (context instanceof GoalsMainActivity) {
                ((GoalsMainActivity) context).updateGoalProgress(goal);
            }
            dialog.dismiss();
        });

        editGoal.setOnClickListener(v -> {
            if (context instanceof GoalsMainActivity) {
                ((GoalsMainActivity) context).editGoalName(goal, position);
            }
            dialog.dismiss();
        });

        deleteGoal.setOnClickListener(v -> {
            onDelete.onDelete(position, goal);
            dialog.dismiss();
        });

        cancelButton.setOnClickListener(v -> dialog.dismiss());

        dialog.show();
    }

    public static class GoalViewHolder extends RecyclerView.ViewHolder {
        TextView goalText, progressText;
        ProgressBar progressBar;
        ImageView reorderHandle;

        public GoalViewHolder(View view) {
            super(view);
            goalText = view.findViewById(R.id.goalText);
            progressText = view.findViewById(R.id.progressText);
            progressBar = view.findViewById(R.id.goalProgressBar);
            reorderHandle = view.findViewById(R.id.reorderHandle);
        }
    }

    public static class CategoryViewHolder extends RecyclerView.ViewHolder {
        TextView categoryText;

        public CategoryViewHolder(View view) {
            super(view);
            categoryText = view.findViewById(R.id.categoryText);
        }
    }
}
