package com.example.cp470_assignment_final_iteration.Goals;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cp470_assignment_final_iteration.AboutActivity;
import com.example.cp470_assignment_final_iteration.Calendar.CalendarMainActivity;
import com.example.cp470_assignment_final_iteration.HelpActivity;
import com.example.cp470_assignment_final_iteration.Notes.NotesMainActivity;
import com.example.cp470_assignment_final_iteration.R;
import com.example.cp470_assignment_final_iteration.Tasks.TaskMainActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GoalsMainActivity extends AppCompatActivity {
    private final List<Goal> goalsList = new ArrayList<>();
    private final List<Object> displayData = new ArrayList<>();
    private RecyclerView goalsRecyclerView;
    private GoalAdapter goalAdapter;
    private static final String PREFS_NAME = "GoalsPrefs";
    private static final String GOALS_KEY = "goals";
    private static final int ADD_GOAL_REQUEST = 1;
    private static final int UPDATE_PROGRESS_REQUEST = 2;
    private boolean isGroupedByCategory = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.goals_activity_goals);

        // Floating Action Button for adding new goals
        FloatingActionButton addGoalFab = findViewById(R.id.addGoalFab);
        addGoalFab.setOnClickListener(v -> {
            Intent intent = new Intent(this, AddGoalActivity.class);
            startActivityForResult(intent, ADD_GOAL_REQUEST);
        });

        // Load saved goals from SharedPreferences
        loadGoals();

        // Initialize RecyclerView
        goalsRecyclerView = findViewById(R.id.goalsRecyclerView);
        goalsRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Toggle grouping by category
        Switch viewSwitch = findViewById(R.id.viewSwitch);
        LinearLayout colorLegend = findViewById(R.id.colorLegend);

        viewSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            isGroupedByCategory = isChecked;
            updateRecyclerView();
            // Show or hide the color legend based on grouping state
            colorLegend.setVisibility(isGroupedByCategory ? LinearLayout.GONE : LinearLayout.VISIBLE);
        });

        // Enable drag-and-drop for goals
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(
                ItemTouchHelper.UP | ItemTouchHelper.DOWN, 0) {
            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                int fromPosition = viewHolder.getAdapterPosition();
                int toPosition = target.getAdapterPosition();

                if (!isGroupedByCategory) {
                    Collections.swap(goalsList, fromPosition, toPosition);
                    updatePriorities();
                    updateRecyclerView();
                    saveGoals();
                }
                return true;
            }

            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                // No swipe action needed
            }
        });

        itemTouchHelper.attachToRecyclerView(goalsRecyclerView);

        // Initialize GoalAdapter
        goalAdapter = new GoalAdapter(this, displayData, (position, item) -> {
            if (item instanceof Goal) {
                Goal goalToRemove = (Goal) item;
                goalsList.remove(goalToRemove);
                updatePriorities();
                updateRecyclerView();
                saveGoals();
            }
        }, itemTouchHelper::startDrag);

        goalsRecyclerView.setAdapter(goalAdapter);

        // Update RecyclerView with current data
        updateRecyclerView();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ADD_GOAL_REQUEST && resultCode == RESULT_OK) {
            String goalText = data.getStringExtra("goalText");
            String category = data.getStringExtra("category");

            if (goalText != null && category != null) {
                // Add the new goal to the list
                goalsList.add(new Goal(goalText, category, 0));
                updatePriorities();
                saveGoals();
                updateRecyclerView();
            }
        } else if (requestCode == UPDATE_PROGRESS_REQUEST && resultCode == RESULT_OK) {
            int position = data.getIntExtra("goalPosition", -1);
            int updatedProgress = data.getIntExtra("updatedProgress", -1);

            if (position >= 0 && updatedProgress >= 0 && position < goalsList.size()) {
                goalsList.get(position).setCurrentProgress(updatedProgress);
                saveGoals();
                updateRecyclerView();
            }
        }
    }

    public void updateGoalProgress(Goal goal) {
        Intent intent = new Intent(this, UpdateProgressActivity.class);
        int position = goalsList.indexOf(goal); // Get the position of the goal
        intent.putExtra("goalPosition", position);
        intent.putExtra("currentProgress", goal.getCurrentProgress());
        startActivityForResult(intent, UPDATE_PROGRESS_REQUEST);
    }

    public void editGoalName(Goal goal, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.edit_goal));

        final EditText input = new EditText(this);
        input.setText(goal.getGoalText());
        builder.setView(input);

        builder.setPositiveButton(getString(R.string.save_goal), (dialog, which) -> {
            String newGoalName = input.getText().toString().trim();
            if (!newGoalName.isEmpty()) {
                goalsList.get(position).setGoalText(newGoalName);
                saveGoals();
                updateRecyclerView();
            }
        });

        builder.setNegativeButton(getString(R.string.cancel), (dialog, which) -> dialog.dismiss());

        builder.show();
    }

    private void saveGoals() {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(goalsList);
        editor.putString(GOALS_KEY, json);
        editor.apply();
    }

    private void loadGoals() {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString(GOALS_KEY, null);
        if (json != null) {
            Type type = new TypeToken<ArrayList<Goal>>() {}.getType();
            goalsList.addAll(gson.fromJson(json, type));
        }
    }

    private void updatePriorities() {
        for (int i = 0; i < goalsList.size(); i++) {
            goalsList.get(i).setPriority(i + 1);
        }
    }

    private void updateRecyclerView() {
        displayData.clear();
        if (isGroupedByCategory) {
            Map<String, List<Goal>> groupedMap = new HashMap<>();
            for (Goal goal : goalsList) {
                groupedMap.computeIfAbsent(goal.getCategory(), k -> new ArrayList<>()).add(goal);
            }
            for (Map.Entry<String, List<Goal>> entry : groupedMap.entrySet()) {
                displayData.add(entry.getKey());
                displayData.addAll(entry.getValue());
            }
        } else {
            displayData.addAll(goalsList);
        }
        goalAdapter.updateData(displayData);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.navigation_menu, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem currentItem = menu.findItem(R.id.goals);
        if (currentItem != null) {
            currentItem.setVisible(false);
        }
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.help) {
            Intent helpMenu = new Intent(this, HelpActivity.class);
            startActivity(helpMenu);
        } else if (item.getItemId() == R.id.about) {
            Intent helpMenu = new Intent(this, AboutActivity.class);
            startActivity(helpMenu);
        } else if (item.getItemId() == R.id.calendar) {
            Intent helpMenu = new Intent(this, CalendarMainActivity.class);
            startActivity(helpMenu);
        } else if (item.getItemId() == R.id.notes) {
            Intent helpMenu = new Intent(this, NotesMainActivity.class);
            startActivity(helpMenu);
        } else if (item.getItemId() == R.id.tasks) {
            Intent helpMenu = new Intent(this, TaskMainActivity.class);
            startActivity(helpMenu);
        } else if (item.getItemId() == R.id.goals) {
            Intent helpMenu = new Intent(this, GoalsMainActivity.class);
            startActivity(helpMenu);
        }
        return super.onOptionsItemSelected(item);
    }
}
