package com.example.cp470_assignment_final_iteration.Goals;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.NumberPicker;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.cp470_assignment_final_iteration.R;

public class UpdateProgressActivity extends AppCompatActivity {
    private NumberPicker progressPicker;
    private TextView progressText;
    private int currentProgress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.goals_progress_update);

        Intent intent = getIntent();
        int position = intent.getIntExtra("goalPosition", -1);
        currentProgress = intent.getIntExtra("currentProgress", 0);

        progressText = findViewById(R.id.progressText);
        progressPicker = findViewById(R.id.progressPicker);

        Button updateButton = findViewById(R.id.updateButton);
        Button cancelButton = findViewById(R.id.cancelButton);

        updateButton.setText(getString(R.string.update_progress));
        cancelButton.setText(getString(R.string.cancel));

        progressPicker.setMinValue(0);
        progressPicker.setMaxValue(10);
        progressPicker.setDisplayedValues(new String[]{"0%", "10%", "20%", "30%", "40%", "50%", "60%", "70%", "80%", "90%", "100%"});
        progressPicker.setValue(currentProgress / 10);

        progressPicker.setOnValueChangedListener((picker, oldVal, newVal) -> {
            int progressValue = newVal * 10;
            progressText.setText(String.format(getString(R.string.progress_completed), progressValue));
        });

        updateButton.setOnClickListener(v -> {
            int updatedProgress = progressPicker.getValue() * 10;
            Intent resultIntent = new Intent();
            resultIntent.putExtra("goalPosition", position);
            resultIntent.putExtra("updatedProgress", updatedProgress);
            setResult(RESULT_OK, resultIntent);
            finish();
        });

        cancelButton.setOnClickListener(v -> finish());
    }
}
