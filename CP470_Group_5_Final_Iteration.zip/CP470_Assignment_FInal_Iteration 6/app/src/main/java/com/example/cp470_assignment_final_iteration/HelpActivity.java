package com.example.cp470_assignment_final_iteration;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.cp470_assignment_final_iteration.Calendar.CalendarMainActivity;
import com.example.cp470_assignment_final_iteration.Goals.GoalsMainActivity;
import com.example.cp470_assignment_final_iteration.Notes.NotesMainActivity;
import com.example.cp470_assignment_final_iteration.Tasks.TaskMainActivity;

public class HelpActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.help_activity);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.navigation_menu, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem currentItem = menu.findItem(R.id.help);
        if (currentItem != null) {
            currentItem.setVisible(false);
        }
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.help) {
            Intent helpMenu = new Intent(this, HelpActivity.class);
            startActivity(helpMenu);
        } else if (item.getItemId() == R.id.about) {
            Intent helpMenu = new Intent(this, AboutActivity.class);
            startActivity(helpMenu);
        } else if (item.getItemId() == R.id.calendar) {
            Intent helpMenu = new Intent(this, CalendarMainActivity.class);
            startActivity(helpMenu);
        } else if (item.getItemId() == R.id.notes) {
            Intent helpMenu = new Intent(this, NotesMainActivity.class);
            startActivity(helpMenu);
        } else if (item.getItemId() == R.id.tasks) {
            Intent helpMenu = new Intent(this, TaskMainActivity.class);
            startActivity(helpMenu);
        } else if (item.getItemId() == R.id.goals) {
            Intent helpMenu = new Intent(this, GoalsMainActivity.class);
            startActivity(helpMenu);
        }
        return super.onOptionsItemSelected(item);
    }
}