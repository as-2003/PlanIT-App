package com.example.cp470_assignment_final_iteration.Login;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.cp470_assignment_final_iteration.Dashboard.DashboardMainActivity;
import com.example.cp470_assignment_final_iteration.R;

public class LoginActivity extends AppCompatActivity {

    private EditText emailInput, passwordInput, nameInput;
    private Button signupButton, confirmLoginButton;
    private TextView switchToLogin, guestLogin;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);

        // Initialize DatabaseHelper
        databaseHelper = new DatabaseHelper(this);

        // Initialize views
        emailInput = findViewById(R.id.emailInput);
        passwordInput = findViewById(R.id.passwordInput);
        nameInput = findViewById(R.id.usernameInput); // For sign-up only
        signupButton = findViewById(R.id.signupButton); // Confirm sign-up
        confirmLoginButton = findViewById(R.id.confirmLoginButton); // For log-in
        switchToLogin = findViewById(R.id.switchToLogin); // Switch between modes
        guestLogin = findViewById(R.id.guestLogin); // Guest Login
        ImageView appLogo = findViewById(R.id.appLogo);

        // Add animation to the logo
        Animation logoAnimation = AnimationUtils.loadAnimation(this, R.anim.logo_animation);
        appLogo.startAnimation(logoAnimation);

        // Initially show Sign-Up mode
        confirmLoginButton.setVisibility(View.GONE);

        // Handle switch to Log-In mode
        switchToLogin.setOnClickListener(v -> {
            if (nameInput.getVisibility() == View.VISIBLE) {
                // Switch to Log-In mode
                nameInput.setVisibility(View.GONE);
                signupButton.setVisibility(View.GONE);
                confirmLoginButton.setVisibility(View.VISIBLE);
                switchToLogin.setText(R.string.switch_to_signup);
            } else {
                // Switch back to Sign-Up mode
                nameInput.setVisibility(View.VISIBLE);
                signupButton.setVisibility(View.VISIBLE);
                confirmLoginButton.setVisibility(View.GONE);
                switchToLogin.setText(R.string.switch_to_login);
            }
        });

        // Handle Log-In
        confirmLoginButton.setOnClickListener(v -> {
            String email = emailInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            // Validate email format
            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                Toast.makeText(this, getString(R.string.invalid_email_format), Toast.LENGTH_SHORT).show();
                return;
            }

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, getString(R.string.fill_all_fields), Toast.LENGTH_SHORT).show();
                return;
            }

            Cursor userCursor = databaseHelper.getUser(email, password);
            if (userCursor != null && userCursor.moveToFirst()) {
                String name = userCursor.getString(userCursor.getColumnIndexOrThrow("name"));
                navigateToDashboard(name);
            } else {
                Toast.makeText(this, getString(R.string.invalid_credentials), Toast.LENGTH_SHORT).show();
            }
        });

        // Handle Sign-Up
        signupButton.setOnClickListener(v -> {
            String name = nameInput.getText().toString().trim();
            String email = emailInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            // Validate email format
            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                Toast.makeText(this, getString(R.string.invalid_email_format), Toast.LENGTH_SHORT).show();
                return;
            }

            if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, getString(R.string.fill_all_fields), Toast.LENGTH_SHORT).show();
                return;
            }

            boolean isAdded = databaseHelper.addUser(name, email, password);
            if (isAdded) {
                Toast.makeText(this, getString(R.string.account_created_successfully), Toast.LENGTH_SHORT).show();
                // Reset fields and switch back to Log-In mode
                nameInput.setText("");
                emailInput.setText("");
                passwordInput.setText("");
                nameInput.setVisibility(View.GONE);
                signupButton.setVisibility(View.GONE);
                confirmLoginButton.setVisibility(View.VISIBLE);
                switchToLogin.setText(R.string.switch_to_signup);
            } else {
                Toast.makeText(this, getString(R.string.account_exists), Toast.LENGTH_SHORT).show();
            }
        });

        // Handle Guest Login
        guestLogin.setOnClickListener(v -> {
            navigateToDashboard("Guest");
        });
    }

    private void navigateToDashboard(String username) {
        Intent intent = new Intent(LoginActivity.this, DashboardMainActivity.class);
        intent.putExtra("username", username);
        startActivity(intent);
        finish();
    }
}
