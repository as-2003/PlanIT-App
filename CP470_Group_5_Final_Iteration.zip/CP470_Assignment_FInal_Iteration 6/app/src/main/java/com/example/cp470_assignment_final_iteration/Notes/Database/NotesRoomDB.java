package com.example.cp470_assignment_final_iteration.Notes.Database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.cp470_assignment_final_iteration.Notes.Models.Notes;

@Database(entities = Notes.class, version = 3, exportSchema = false)
public abstract class NotesRoomDB extends RoomDatabase {
    private static NotesRoomDB database;
    private static String DATABASE_NAME = "NoteApp";

    public synchronized static NotesRoomDB getInstance(Context context) {
        if (database == null) {
            database = Room.databaseBuilder(context.getApplicationContext(),
                    NotesRoomDB.class, DATABASE_NAME)
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return database;
    }

    public abstract NotesMainDataAccessObject mainDAO();
}
