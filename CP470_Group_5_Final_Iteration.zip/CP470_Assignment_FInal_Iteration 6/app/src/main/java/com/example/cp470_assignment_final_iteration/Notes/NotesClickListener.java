package com.example.cp470_assignment_final_iteration.Notes;

import androidx.cardview.widget.CardView;

import com.example.cp470_assignment_final_iteration.Notes.Models.Notes;

public interface NotesClickListener {
    void onClick(Notes notes);
    void onLongClick(Notes notes, CardView cardView);
}
