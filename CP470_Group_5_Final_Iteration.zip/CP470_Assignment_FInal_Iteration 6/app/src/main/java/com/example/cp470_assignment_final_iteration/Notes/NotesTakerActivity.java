package com.example.cp470_assignment_final_iteration.Notes;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.cp470_assignment_final_iteration.Notes.Models.Notes;
import com.example.cp470_assignment_final_iteration.Notes.OCR.OCRMainActivity;
import com.example.cp470_assignment_final_iteration.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

public class NotesTakerActivity extends AppCompatActivity {
    EditText editText_title, editText_notes;
    ImageView imageView_save;
    FloatingActionButton camera_FAB;
    Notes notes;
    boolean isOldNote = false;
    Spinner categorySpinner;
    ArrayList<String> categoryList = new ArrayList<>();
    ArrayAdapter<String> categoryAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notes_activity_notes_taker);

        imageView_save = findViewById(R.id.imageView_save);
        editText_notes = findViewById(R.id.editText_notes);
        editText_title = findViewById(R.id.editText_title);
        camera_FAB = findViewById(R.id.cameraFAB);

        // Add categories from strings.xml
        String[] categoriesArray = getResources().getStringArray(R.array.categories);
        categoryList.add(getString(R.string.select_category));
        categoryList.addAll(Arrays.asList(categoriesArray));

        categorySpinner = findViewById(R.id.categorySpinner);

        // Set up ArrayAdapter with default text color
        categoryAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categoryList);
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(categoryAdapter);

        notes = new Notes();
        try {
            notes = (Notes) getIntent().getSerializableExtra("old_note");
            editText_title.setText(notes.getTitle());
            editText_notes.setText(notes.getNote());
            int index = categoryList.indexOf(notes.getCategory());
            categorySpinner.setSelection(index);
            isOldNote = true;
        } catch (Exception e) {
            e.printStackTrace();
        }

        imageView_save.setOnClickListener(view -> {
            String title = editText_title.getText().toString();
            String note = editText_notes.getText().toString();
            String category = categorySpinner.getSelectedItem().toString();

            if (note.isEmpty()) {
                Toast.makeText(NotesTakerActivity.this, getString(R.string.add_note_message), Toast.LENGTH_LONG).show();
            } else {
                SimpleDateFormat formatter = new SimpleDateFormat("MMM d, yyyy HH:mm a");
                Date date = new Date();

                if (!isOldNote) {
                    notes = new Notes();
                }

                notes.setTitle(title);
                notes.setNote(note);
                notes.setDate(formatter.format(date));
                notes.setCategory(category);

                Intent intent = new Intent();
                intent.putExtra("note", notes);
                setResult(NotesTakerActivity.RESULT_OK, intent);
                finish();
            }
        });

        camera_FAB.setOnClickListener(view -> {
            Intent intent = new Intent(NotesTakerActivity.this, OCRMainActivity.class);
            startActivityForResult(intent, 100);
        });

        categorySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                // Handle category selection
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                // Handle no selection
            }
        });
    }
}
