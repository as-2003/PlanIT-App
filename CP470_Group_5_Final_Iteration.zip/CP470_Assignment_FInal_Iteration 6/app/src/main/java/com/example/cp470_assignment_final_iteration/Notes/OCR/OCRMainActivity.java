package com.example.cp470_assignment_final_iteration.Notes.OCR;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.cp470_assignment_final_iteration.R;
import com.google.android.gms.vision.Frame;
import com.google.android.gms.vision.text.TextBlock;
import com.google.android.gms.vision.text.TextRecognizer;

import java.io.FileNotFoundException;
import java.io.InputStream;

public class OCRMainActivity extends AppCompatActivity {
    Button CaptureButton, CopyButton, BackButton, GalleryButton;
    TextView TextDataTextView;
    private ActivityResultLauncher<Intent> takePictureLauncher;
    private static final int GALLERY_REQUEST = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.ocr_activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        CaptureButton = findViewById(R.id.CaptureButton);
        CopyButton = findViewById(R.id.CopyButton);
        TextDataTextView = findViewById(R.id.TextDataTextView);
        BackButton = findViewById(R.id.BackButton);
        GalleryButton = findViewById(R.id.GalleryButton);

        takePictureLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        Bundle extras = result.getData().getExtras();
                        Bitmap imageBitmap = (Bitmap) extras.get("data");
                        getTextFromImage(imageBitmap);
                        Log.i("OCRMainActivity.java", "Image received");
                    }
                });

        CaptureButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                    takePictureLauncher.launch(takePictureIntent);
                }
                else {
                    Log.d("OCRMainActivity.java", "No Camera App found");
                }
            }
        });

        CopyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String scannedText = TextDataTextView.getText().toString();
                copyToClipboard(scannedText);
            }
        });

        BackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        GalleryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent();
                i.setType("image/*");
                i.setAction(Intent.ACTION_GET_CONTENT);

                // pass the constant to compare it
                // with the returned requestCode
                startActivityForResult(Intent.createChooser(i, "Select Picture"), GALLERY_REQUEST);
            }
        });
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            // compare the resultCode with the
            // SELECT_PICTURE constant
            if (requestCode == GALLERY_REQUEST) {
                // Get the url of the image from data
                Uri selectedImageUri = data.getData();
                final InputStream imageStream;
                try {
                    assert selectedImageUri != null;
                    imageStream = getContentResolver().openInputStream(selectedImageUri);
                } catch (FileNotFoundException e) {
                    throw new RuntimeException(e);
                }
                final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                getTextFromImage(selectedImage);
            }
        }
    }

    /*
    private void getTextFromImage(Bitmap bitmap) {
        TextRecognizer recognizer = new TextRecognizer.Builder(this).build();
        if (!recognizer.isOperational()) {
            Toast.makeText(OCRMainActivity.this, getString(R.string.no_text_message), Toast.LENGTH_LONG).show();
        }
        else {
            Frame frame = new Frame.Builder().setBitmap(bitmap).build();
            SparseArray<TextBlock> textBlockSparseArray = recognizer.detect(frame);
            StringBuilder stringBuilder = new StringBuilder();
            for (int i = 0; i < textBlockSparseArray.size(); i++) {
                TextBlock textBlock = textBlockSparseArray.valueAt(i);
                stringBuilder.append(textBlock.getValue());
                stringBuilder.append("\n");
            }
            TextDataTextView.setText(stringBuilder.toString());
            CaptureButton.setText(getString(R.string.recapture_button));
            CopyButton.setVisibility(View.VISIBLE);
        }
    }

     */
    private void getTextFromImage(Bitmap bitmap) {
        new AsyncTask<Bitmap, Void, String>() {
            @Override
            protected String doInBackground(Bitmap... bitmaps) {
                TextRecognizer recognizer = new TextRecognizer.Builder(OCRMainActivity.this).build();
                if (!recognizer.isOperational()) {
                    return null;
                }
                Frame frame = new Frame.Builder().setBitmap(bitmaps[0]).build();
                SparseArray<TextBlock> textBlockSparseArray = recognizer.detect(frame);
                StringBuilder stringBuilder = new StringBuilder();

                for (int i = 0; i < textBlockSparseArray.size(); i++) {
                    TextBlock textBlock = textBlockSparseArray.valueAt(i);
                    stringBuilder.append(textBlock.getValue()).append("\n");
                }
                return stringBuilder.toString();
            }

            @Override
            protected void onPostExecute(String result) {
                if (result == null) {
                    Toast.makeText(OCRMainActivity.this, getString(R.string.no_text_message), Toast.LENGTH_LONG).show();
                } else {
                    TextDataTextView.setText(result);
                    CaptureButton.setText(getString(R.string.recapture_button));
                    CopyButton.setVisibility(View.VISIBLE);
                }
            }
        }.execute(bitmap);
    }

    private void copyToClipboard(String text) {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("Copied data", text);
        clipboard.setPrimaryClip(clip);
        Toast.makeText(OCRMainActivity.this, getString(R.string.copied_to_clipboard), Toast.LENGTH_SHORT).show();
    }
}