package com.example.cp470_assignment_final_iteration.Tasks;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "TaskApp.db";
    public static final int DATABASE_VERSION = 3; // Incremented version for migration

    // Table and column names
    public static final String TABLE_TASKS = "tasks";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_DESCRIPTION = "description"; // New column
    public static final String COLUMN_DEADLINE = "deadline";
    public static final String COLUMN_PRIORITY = "priority";
    public static final String COLUMN_COMPLETED = "completed";
    public static final String COLUMN_CATEGORY = "category";

    // Create table SQL
    private static final String CREATE_TABLE_TASKS = "CREATE TABLE " + TABLE_TASKS + " (" +
            COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_NAME + " TEXT, " +
            COLUMN_DESCRIPTION + " TEXT, " + // Add description column
            COLUMN_DEADLINE + " TEXT, " +
            COLUMN_PRIORITY + " TEXT, " +
            COLUMN_COMPLETED + " INTEGER DEFAULT 0, " +
            COLUMN_CATEGORY + " TEXT" +
            ");";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_TASKS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE " + TABLE_TASKS + " ADD COLUMN " + COLUMN_DESCRIPTION + " TEXT");
        }
    }
}
