package com.example.cp470_assignment_final_iteration.Tasks;

public class Task {
    private String name;
    private String description; // Add description field
    private String deadline;
    private String priority;
    private String category; // Add category field
    private boolean isCompleted;

    public Task(String name, String description, String deadline, String priority, String category) {
        this.name = name;
        this.description = description;
        this.deadline = deadline;
        this.priority = priority;
        this.category = category;
        this.isCompleted = false; // Default to not completed
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getDeadline() {
        return deadline;
    }

    public String getPriority() {
        return priority;
    }

    public String getCategory() {
        return category;
    }

    public boolean isCompleted() {
        return isCompleted;
    }

    public void setCompleted(boolean completed) {
        isCompleted = completed;
    }

    public int getPriorityLevel() {
        switch (priority.toLowerCase()) {
            case "high":
                return 1;
            case "medium":
                return 2;
            case "low":
                return 3;
            default:
                return Integer.MAX_VALUE;
        }
    }
}
