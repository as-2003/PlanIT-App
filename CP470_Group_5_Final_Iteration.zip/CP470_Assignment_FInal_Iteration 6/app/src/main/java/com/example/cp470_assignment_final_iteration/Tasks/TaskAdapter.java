package com.example.cp470_assignment_final_iteration.Tasks;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cp470_assignment_final_iteration.R;

import java.util.List;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {

    private final List<Task> taskList;
    private final Context context;
    private final TaskDAO taskDAO; // Database access object

    public TaskAdapter(Context context, List<Task> taskList) {
        this.context = context;
        this.taskList = taskList;
        this.taskDAO = new TaskDAO(context); // Initialize the DAO
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.task_item_task, parent, false);
        return new TaskViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        Task task = taskList.get(position);
        holder.textTaskName.setText(task.getName());
        holder.textDeadline.setText(context.getString(R.string.task_due) + task.getDeadline());
        holder.textPriority.setText(context.getString(R.string.task_priority) + task.getPriority());
        holder.checkBoxCompleted.setChecked(task.isCompleted());

        // Apply category-based text color using the color codes
        switch (task.getCategory()) {
            case "Work":
                holder.textTaskName.setTextColor(context.getResources().getColor(R.color.blue));
                break;
            case "Academic":
                holder.textTaskName.setTextColor(context.getResources().getColor(R.color.purple));
                break;
            case "Personal":
                holder.textTaskName.setTextColor(context.getResources().getColor(R.color.yellow));
                break;
            case "Other":
                holder.textTaskName.setTextColor(context.getResources().getColor(R.color.green));
                break;
            default:
                holder.textTaskName.setTextColor(context.getResources().getColor(R.color.gray));
                break;
        }

        // Handle checkbox toggle
        holder.checkBoxCompleted.setOnCheckedChangeListener((buttonView, isChecked) -> {
            task.setCompleted(isChecked);
            taskDAO.updateTaskStatus(task.getName(), isChecked);

            String message = isChecked ? context.getString(R.string.task_completed) : context.getString(R.string.task_incompleted);
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
        });

        // Handle delete button click
        holder.buttonDelete.setOnClickListener(v -> {
            taskDAO.deleteTask(task.getName());
            taskList.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, taskList.size());
            Toast.makeText(context, context.getString(R.string.task_deleted), Toast.LENGTH_SHORT).show();
        });

        // Show task details on click
        holder.itemView.setOnClickListener(v -> {
            new AlertDialog.Builder(context)
                    .setTitle(task.getName())
                    .setMessage(
                            context.getString(R.string.task_description) + task.getDescription() + "\n" +
                                    context.getString(R.string.task_deadline) + task.getDeadline() + "\n" +
                                    context.getString(R.string.task_priority) + task.getPriority() + "\n" +
                                    context.getString(R.string.task_category) + task.getCategory()
                    )
                    .setPositiveButton(context.getString(R.string.ok_button), null)
                    .create()
                    .show();
        });
    }

    @Override
    public int getItemCount() {
        return taskList.size();
    }

    public void updateTaskList(List<Task> newTaskList) {
        taskList.clear();
        taskList.addAll(newTaskList);
        notifyDataSetChanged();
    }

    public static class TaskViewHolder extends RecyclerView.ViewHolder {
        TextView textTaskName, textDeadline, textPriority;
        CheckBox checkBoxCompleted;
        Button buttonDelete;

        public TaskViewHolder(@NonNull View itemView) {
            super(itemView);
            textTaskName = itemView.findViewById(R.id.textTaskName);
            textDeadline = itemView.findViewById(R.id.textDeadline);
            textPriority = itemView.findViewById(R.id.textPriority);
            checkBoxCompleted = itemView.findViewById(R.id.checkBoxCompleted);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
        }
    }
}
