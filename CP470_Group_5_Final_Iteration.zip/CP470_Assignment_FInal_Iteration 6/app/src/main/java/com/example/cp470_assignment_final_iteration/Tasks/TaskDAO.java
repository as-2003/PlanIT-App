package com.example.cp470_assignment_final_iteration.Tasks;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class TaskDAO {

    private final DatabaseHelper dbHelper;

    public TaskDAO(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    // Insert a new task
    public long insertTask(Task task) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_NAME, task.getName());
        values.put(DatabaseHelper.COLUMN_DESCRIPTION, task.getDescription()); // Add description
        values.put(DatabaseHelper.COLUMN_DEADLINE, task.getDeadline());
        values.put(DatabaseHelper.COLUMN_PRIORITY, task.getPriority());
        values.put(DatabaseHelper.COLUMN_COMPLETED, task.isCompleted() ? 1 : 0);
        values.put(DatabaseHelper.COLUMN_CATEGORY, task.getCategory());
        return db.insert(DatabaseHelper.TABLE_TASKS, null, values);
    }


    // Get all tasks
    public List<Task> getAllTasks() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        List<Task> tasks = new ArrayList<>();
        Cursor cursor = db.query(DatabaseHelper.TABLE_TASKS, null, null, null, null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                Task task = new Task(
                        cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME)),
                        cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_DESCRIPTION)), // Get description
                        cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_DEADLINE)),
                        cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_PRIORITY)),
                        cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_CATEGORY))
                );
                task.setCompleted(cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_COMPLETED)) == 1);
                tasks.add(task);
            }
            cursor.close();
        }
        return tasks;
    }


    // Delete a task by name
    public void deleteTask(String taskName) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(DatabaseHelper.TABLE_TASKS, DatabaseHelper.COLUMN_NAME + " = ?", new String[]{taskName});
        db.close();
    }

    // Delete completed tasks
    public void deleteCompletedTasks() {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(DatabaseHelper.TABLE_TASKS, DatabaseHelper.COLUMN_COMPLETED + " = 1", null);
        db.close();
    }

    // Get tasks by priority
    public List<Task> getTasksByPriority(String priority) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        List<Task> tasks = new ArrayList<>();
        Cursor cursor = db.query(DatabaseHelper.TABLE_TASKS,
                null,
                DatabaseHelper.COLUMN_PRIORITY + " = ?",
                new String[]{priority},
                null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                Task task = new Task(
                        cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME)),
                        cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_DESCRIPTION)), // Get description
                        cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_DEADLINE)),
                        cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_PRIORITY)),
                        cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_CATEGORY))
                );
                task.setCompleted(cursor.getInt(cursor.getColumnIndex(DatabaseHelper.COLUMN_COMPLETED)) == 1);
                tasks.add(task);
            }
            cursor.close();
        }
        return tasks;
    }

    // Update task completion status
    public void updateTaskStatus(String taskName, boolean isCompleted) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_COMPLETED, isCompleted ? 1 : 0);
        db.update(DatabaseHelper.TABLE_TASKS, values, DatabaseHelper.COLUMN_NAME + " = ?", new String[]{taskName});
        db.close();
    }
}
