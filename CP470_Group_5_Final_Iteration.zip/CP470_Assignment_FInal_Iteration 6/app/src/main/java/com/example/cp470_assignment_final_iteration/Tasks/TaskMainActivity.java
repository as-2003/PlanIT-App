package com.example.cp470_assignment_final_iteration.Tasks;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent; // Added for Help and About functionality
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu; // Added for Help and About menu
import android.view.MenuItem; // Added for Help and About menu
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cp470_assignment_final_iteration.AboutActivity; // Added for AboutActivity
import com.example.cp470_assignment_final_iteration.Calendar.CalendarMainActivity;
import com.example.cp470_assignment_final_iteration.Goals.GoalsMainActivity;
import com.example.cp470_assignment_final_iteration.HelpActivity;  // Added for HelpActivity
import com.example.cp470_assignment_final_iteration.Notes.NotesMainActivity;
import com.example.cp470_assignment_final_iteration.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class TaskMainActivity extends AppCompatActivity {

    private TaskAdapter taskAdapter;
    private TaskDAO taskDAO;
    private List<Task> taskList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.task_activity_main);

        taskDAO = new TaskDAO(this);
        taskList = taskDAO.getAllTasks();

        RecyclerView recyclerView = findViewById(R.id.recyclerViewTasks);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        taskAdapter = new TaskAdapter(this, taskList);
        recyclerView.setAdapter(taskAdapter);

        findViewById(R.id.fabAddTask).setOnClickListener(v -> showAddTaskDialog());
        findViewById(R.id.buttonFilter).setOnClickListener(v -> filterTasksByPriority());
    }

    private void showAddTaskDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.task_dialog_add_task, null);
        EditText editTaskName = dialogView.findViewById(R.id.editTaskName);
        EditText editDescription = dialogView.findViewById(R.id.editDescription);
        TextView editDeadline = dialogView.findViewById(R.id.editDeadline);
        Spinner spinnerPriority = dialogView.findViewById(R.id.spinnerPriority);
        Spinner spinnerCategory = dialogView.findViewById(R.id.spinnerCategory);
        Button buttonAdd = dialogView.findViewById(R.id.buttonAddTask);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(dialogView)
                .create();

        final Calendar selectedDateTime = Calendar.getInstance();

        editDeadline.setOnClickListener(v -> {
            Calendar currentDate = Calendar.getInstance();
            DatePickerDialog datePicker = new DatePickerDialog(
                    this,
                    (view, year, month, dayOfMonth) -> {
                        selectedDateTime.set(year, month, dayOfMonth);

                        TimePickerDialog timePicker = new TimePickerDialog(
                                this,
                                (timeView, hourOfDay, minute) -> {
                                    selectedDateTime.set(Calendar.HOUR_OF_DAY, hourOfDay);
                                    selectedDateTime.set(Calendar.MINUTE, minute);

                                    if (selectedDateTime.before(Calendar.getInstance())) {
                                        Toast.makeText(this, getString(R.string.select_future_date_message), Toast.LENGTH_SHORT).show();
                                    } else {
                                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
                                        editDeadline.setText(sdf.format(selectedDateTime.getTime()));
                                    }
                                },
                                currentDate.get(Calendar.HOUR_OF_DAY),
                                currentDate.get(Calendar.MINUTE),
                                true
                        );
                        timePicker.show();
                    },
                    currentDate.get(Calendar.YEAR),
                    currentDate.get(Calendar.MONTH),
                    currentDate.get(Calendar.DAY_OF_MONTH)
            );

            datePicker.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
            datePicker.show();
        });

        buttonAdd.setOnClickListener(v -> {
            String taskName = editTaskName.getText().toString();
            String description = editDescription.getText().toString();
            String deadline = editDeadline.getText().toString();
            String priority = spinnerPriority.getSelectedItem().toString();
            String category = spinnerCategory.getSelectedItem().toString();

            if (!taskName.isEmpty() && !description.isEmpty() && !deadline.isEmpty()) {
                Task newTask = new Task(taskName, description, deadline, priority, category);
                taskDAO.insertTask(newTask);
                refreshTaskList();
                dialog.dismiss();
            } else {
                Toast.makeText(this, getString(R.string.fill_all_fields), Toast.LENGTH_SHORT).show();
            }
        });

        dialog.show();
    }

    private void refreshTaskList() {
        taskList.clear();
        taskList.addAll(taskDAO.getAllTasks());
        taskAdapter.notifyDataSetChanged();
    }

    private void filterTasksByPriority() {
        // Retrieve the priority array from strings.xml
        String[] priorities = getResources().getStringArray(R.array.priority_array);

        new AlertDialog.Builder(this)
                .setTitle(getString(R.string.select_priority))
                .setItems(priorities, (dialog, which) -> {
                    String selectedPriority = priorities[which];
                    List<Task> filteredList = taskDAO.getTasksByPriority(selectedPriority);

                    taskAdapter.updateTaskList(filteredList);
                })
                .setPositiveButton(getString(R.string.show_all_button), (dialog, which) -> {
                    refreshTaskList();
                })
                .create()
                .show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.navigation_menu, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem currentItem = menu.findItem(R.id.tasks);
        if (currentItem != null) {
            currentItem.setVisible(false);
        }
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.help) {
            Intent helpMenu = new Intent(this, HelpActivity.class);
            startActivity(helpMenu);
        } else if (item.getItemId() == R.id.about) {
            Intent helpMenu = new Intent(this, AboutActivity.class);
            startActivity(helpMenu);
        } else if (item.getItemId() == R.id.calendar) {
            Intent helpMenu = new Intent(this, CalendarMainActivity.class);
            startActivity(helpMenu);
        } else if (item.getItemId() == R.id.notes) {
            Intent helpMenu = new Intent(this, NotesMainActivity.class);
            startActivity(helpMenu);
        } else if (item.getItemId() == R.id.tasks) {
            Intent helpMenu = new Intent(this, TaskMainActivity.class);
            startActivity(helpMenu);
        } else if (item.getItemId() == R.id.goals) {
            Intent helpMenu = new Intent(this, GoalsMainActivity.class);
            startActivity(helpMenu);
        }
        return super.onOptionsItemSelected(item);
    }
}
